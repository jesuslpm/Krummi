//! Helpers shared by the tree tests: stores on disk and temporary, error matchers, file comparison, page damage,
//! scans, and the models of a multi-value tree and of a fixed-size tree.

#![allow(dead_code)]

use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Path, PathBuf};

use krummi_pager::DATA_FILE;
use krummi_pager::format::PAGE_SIZE;
use krummi_tree::{catalog, fixed};
use krummi_tx::{Engine, OpenOptions as EngineOptions};

use krummi::{
    Error, OpenMode, Result, SizeSubject, Store, StoreOptions, TreeKind, WriteFixedTree,
    WriteMultiTree, WriteTransaction, WriteTree,
};

pub const NORMAL: TreeKind = TreeKind::Normal;
pub const MULTI: TreeKind = TreeKind::MultiValue;

/// The modes of A1 besides Open.
pub const MODES: [OpenMode; 4] = [
    OpenMode::CreateNew,
    OpenMode::OpenOrCreate,
    OpenMode::CreateOrEmpty,
    OpenMode::Empty,
];
// The size limits are written out on purpose instead of taken from the engine: they pin the PRDs' limits (B4, B5,
// V1 of the large values PRD, which replaced A11), so a change in the engine's constants fails these tests.
pub const MAX_NAME: usize = 1024;
pub const MAX_KEY: usize = 2048;
pub const MAX_VALUE: usize = 268_435_456;

/// Runs `test` on a store on disk and on a temporary one; `folder` is the store's folder, `None` when temporary.
pub fn stores(test: impl Fn(&Store, Option<&Path>)) {
    let tmp = tempfile::tempdir().unwrap();
    let on_disk = Store::open(tmp.path(), &StoreOptions::default()).unwrap();
    test(&on_disk, Some(tmp.path()));
    on_disk.close().unwrap();
    let in_memory = Store::open_temporary(&StoreOptions::default()).unwrap();
    test(&in_memory, None);
    in_memory.close().unwrap();
}

pub fn open(folder: &Path) -> Store {
    Store::open(folder, &StoreOptions::default()).unwrap()
}

pub fn create<'s>(write: &mut WriteTransaction<'s>, name: &str) -> WriteTree<'s> {
    write.open_tree_with(name, OpenMode::CreateNew).unwrap()
}

/// What a multi-value tree holds: each key with its values, both in byte order (M1).
pub type Model = BTreeMap<Vec<u8>, BTreeSet<Vec<u8>>>;

pub fn create_multi<'s>(write: &mut WriteTransaction<'s>, name: &str) -> WriteMultiTree<'s> {
    write
        .open_multi_tree_with(name, OpenMode::CreateNew)
        .unwrap()
}

/// Commits the multi-value tree `name`, created if missing, with the keys and values of `model` added.
pub fn commit_multi(store: &Store, name: &str, model: &Model) {
    let mut write = store.write().unwrap();
    let tree = write
        .open_multi_tree_with(name, OpenMode::OpenOrCreate)
        .unwrap();
    for (key, values) in model {
        for value in values {
            write.add(&tree, key, value).unwrap();
        }
    }
    write.commit().unwrap();
}

/// The set of `values`.
pub fn set_of(values: &[&[u8]]) -> BTreeSet<Vec<u8>> {
    values.iter().map(|value| value.to_vec()).collect()
}

/// A value of 16 bytes, the decimal digits of `i`, so that values sort by `i`.
pub fn value16(i: usize) -> Vec<u8> {
    format!("{i:016}").into_bytes()
}

/// What a fixed-size tree holds: each key with its value, in numeric order of the keys (X5).
pub type FixedModel = BTreeMap<u64, Vec<u8>>;

/// The fixed-size tree `name` created with values of `len` bytes.
pub fn create_fixed<'s>(
    write: &mut WriteTransaction<'s>,
    name: &str,
    len: usize,
) -> WriteFixedTree<'s> {
    write
        .open_fixed_tree_with(name, len, OpenMode::CreateNew)
        .unwrap()
}

/// Commits the fixed-size tree `name` of values of `len` bytes, created if missing, with the entries of `model`.
pub fn commit_fixed(store: &Store, name: &str, len: usize, model: &FixedModel) {
    let mut write = store.write().unwrap();
    let tree = write
        .open_fixed_tree_with(name, len, OpenMode::OpenOrCreate)
        .unwrap();
    for (key, value) in model {
        write.set_fixed(&tree, *key, value).unwrap();
    }
    write.commit().unwrap();
}

/// A value of `len` bytes for `key`, which counts up from the low byte of the key, so that close keys get different
/// values.
pub fn fixed_value(key: u64, len: usize) -> Vec<u8> {
    (0..len)
        .map(|i| (key as u8).wrapping_add(i as u8))
        .collect()
}

/// The entries of `keys` with their [`fixed_value`] of `len` bytes.
pub fn fixed_model(keys: impl IntoIterator<Item = u64>, len: usize) -> FixedModel {
    keys.into_iter()
        .map(|key| (key, fixed_value(key, len)))
        .collect()
}

/// Collects a scan, owning each item with `own`.
pub fn collect<T, U>(scan: impl Iterator<Item = Result<T>>, own: impl Fn(T) -> U) -> Vec<U> {
    scan.map(|item| item.map(&own))
        .collect::<Result<_>>()
        .unwrap()
}

/// Collects a scan taking one item from the front and one from the back in turn.
pub fn alternate<T, U>(
    mut scan: impl DoubleEndedIterator<Item = Result<T>>,
    own: impl Fn(T) -> U,
) -> Vec<U> {
    let (mut front, mut back) = (Vec::new(), Vec::new());
    loop {
        match scan.next() {
            Some(item) => front.push(own(item.unwrap())),
            None => break,
        }
        match scan.next_back() {
            Some(item) => back.push(own(item.unwrap())),
            None => break,
        }
    }
    front.extend(back.into_iter().rev());
    front
}

pub fn reversed<T>(mut items: Vec<T>) -> Vec<T> {
    items.reverse();
    items
}

/// A linear congruential generator, so that the random orders are the same on every run.
pub struct Lcg(pub u64);

impl Lcg {
    /// The next number, of 31 bits.
    pub fn next(&mut self) -> u64 {
        self.0 = self
            .0
            .wrapping_mul(6_364_136_223_846_793_005)
            .wrapping_add(1_442_695_040_888_963_407);
        self.0 >> 33
    }

    /// The next number, of 64 bits.
    pub fn next_u64(&mut self) -> u64 {
        (self.next() << 33) ^ (self.next() << 2) ^ self.next()
    }

    pub fn shuffle<T>(&mut self, items: &mut [T]) {
        for i in (1..items.len()).rev() {
            let j = (self.next() % (i as u64 + 1)) as usize;
            items.swap(i, j);
        }
    }
}

/// The pages in use: the pages of the store minus its free pages, as its information gives them.
pub fn in_use(store: &Store) -> u64 {
    let info = store.info();
    info.page_count - info.free_pages
}

/// A store of the same kind as the one of `folder`: on disk in a new folder, or temporary.
pub fn store_like(folder: Option<&Path>) -> (Store, Option<tempfile::TempDir>) {
    match folder {
        Some(_) => {
            let tmp = tempfile::tempdir().unwrap();
            (open(tmp.path()), Some(tmp))
        }
        None => (
            Store::open_temporary(&StoreOptions::default()).unwrap(),
            None,
        ),
    }
}

/// No entries, for [`commit_tree`].
pub const EMPTY: &[(&[u8], &[u8])] = &[];

/// Commits a tree `name` with `entries`.
pub fn commit_tree(store: &Store, name: &str, entries: &[(impl AsRef<[u8]>, impl AsRef<[u8]>)]) {
    let mut write = store.write().unwrap();
    let tree = write.open_tree_with(name, OpenMode::OpenOrCreate).unwrap();
    for (key, value) in entries {
        write.set(&tree, key.as_ref(), value.as_ref()).unwrap();
    }
    write.commit().unwrap();
}

pub fn names(store: &Store) -> Vec<String> {
    let read = store.read().unwrap();
    read.list_trees()
        .unwrap()
        .into_iter()
        .map(|(name, kind)| {
            assert_eq!(kind, NORMAL);
            name
        })
        .collect()
}

pub fn folder_of(folder: Option<&Path>) -> Option<PathBuf> {
    folder.map(Path::to_path_buf)
}

/// The tree name of a tree-not-found error, after checking its folder.
#[track_caller]
pub fn not_found(error: Error, folder: Option<&Path>) -> String {
    match error {
        Error::TreeNotFound { folder: f, name } => {
            assert_eq!(f, folder_of(folder));
            name
        }
        other => panic!("expected tree not found, got {other}"),
    }
}

/// The tree name of a tree-already-exists error, after checking its folder.
#[track_caller]
pub fn already_exists(error: Error, folder: Option<&Path>) -> String {
    match error {
        Error::TreeAlreadyExists { folder: f, name } => {
            assert_eq!(f, folder_of(folder));
            name
        }
        other => panic!("expected tree already exists, got {other}"),
    }
}

/// The subject, received size, minimum and maximum of an invalid-size error, after checking its folder.
#[track_caller]
pub fn invalid_size(error: Error, folder: Option<&Path>) -> (SizeSubject, u64, u64, u64) {
    match error {
        Error::InvalidSize {
            folder: f,
            what,
            received,
            min,
            max,
        } => {
            assert_eq!(f, folder_of(folder));
            (what, received, min, max)
        }
        other => panic!("expected invalid size, got {other}"),
    }
}

/// The fields of a different-tree-type error, after checking its folder.
#[track_caller]
pub fn different(error: Error, folder: Option<&Path>) -> (String, TreeKind, TreeKind) {
    match error {
        Error::DifferentTreeType {
            folder: f,
            name,
            found,
            requested,
        } => {
            assert_eq!(f, folder_of(folder));
            (name, found, requested)
        }
        other => panic!("expected a different tree type, got {other}"),
    }
}

#[track_caller]
pub fn misuse(error: Error, folder: Option<&Path>) {
    match error {
        Error::Misuse { folder: f, .. } => assert_eq!(f, folder_of(folder)),
        other => panic!("expected misuse, got {other}"),
    }
}

/// Every file of the store's folder with its bytes, in name order, subfolders included.
pub fn files(folder: &Path) -> Vec<(PathBuf, Vec<u8>)> {
    let mut out = Vec::new();
    let mut pending = vec![folder.to_path_buf()];
    while let Some(dir) = pending.pop() {
        for entry in fs::read_dir(dir).unwrap() {
            let path = entry.unwrap().path();
            if path.is_dir() {
                pending.push(path);
            } else {
                let bytes = fs::read(&path).unwrap();
                out.push((path, bytes));
            }
        }
    }
    out.sort();
    out
}

/// Runs `change` on a closed store on disk and returns whether its files changed: they are taken after a clean
/// close before and after, and a store reopened and closed without changes keeps them (S1 of the journal).
pub fn files_change(folder: &Path, change: impl FnOnce(&Store)) -> bool {
    let before = files(folder);
    let store = open(folder);
    change(&store);
    store.close().unwrap();
    files(folder) != before
}

/// Runs `look` on a read of the closed store through the engine's internals, which opening and closing without
/// changes leave as they were.
pub fn inspect<T>(folder: &Path, look: impl FnOnce(&krummi_tx::ReadTransaction<'_>) -> T) -> T {
    let engine = Engine::open(folder, &EngineOptions::default()).unwrap();
    let read = engine.read().unwrap();
    let seen = look(&read);
    drop(read);
    engine.close().unwrap();
    seen
}

/// The page of the leaf where `key` is or would be in the closed store: in the tree `tree`, or in the catalog when
/// `tree` is `None` (then `key` is a tree name).
pub fn leaf_page(folder: &Path, tree: Option<&str>, key: &[u8]) -> u64 {
    inspect(folder, |read| {
        let root = match tree {
            Some(name) => catalog::lookup(read, name).unwrap().unwrap().root,
            None => read.slot(catalog::ROOT_SLOT).unwrap(),
        };
        krummi_tree::leaf_of(read, root, key).unwrap()
    })
}

/// The value run of `key` in the tree `tree` of the closed store: its first page and its number of pages, or `None`
/// when the value is in its leaf.
pub fn value_run(folder: &Path, tree: &str, key: &[u8]) -> Option<(u64, u64)> {
    inspect(folder, |read| {
        let root = catalog::lookup(read, tree).unwrap().unwrap().root;
        krummi_tree::run_of(read, root, key).unwrap()
    })
}

/// The root page of the tree `tree` in the closed store.
pub fn root_page(folder: &Path, tree: &str) -> u64 {
    inspect(folder, |read| {
        catalog::lookup(read, tree).unwrap().unwrap().root
    })
}

/// The root page of the subtree of `key` in the multi-value tree `tree` of the closed store, and its number of
/// levels.
pub fn subtree_root(folder: &Path, tree: &str, key: &[u8]) -> (u64, u8) {
    inspect(folder, |read| {
        let root = catalog::lookup(read, tree).unwrap().unwrap().root;
        let subtree = krummi_tree::multi::subtree_of(read, root, key)
            .unwrap()
            .expect("the key's values are in a subtree");
        (subtree, krummi_tree::height(read, subtree).unwrap())
    })
}

/// The number of levels of the tree `tree` of the closed store.
pub fn height(folder: &Path, tree: &str) -> u8 {
    inspect(folder, |read| {
        let root = catalog::lookup(read, tree).unwrap().unwrap().root;
        krummi_tree::height(read, root).unwrap()
    })
}

/// The page of the leaf where `key` is or would be in the fixed-size tree `tree`, of values of `len` bytes, of the
/// closed store.
pub fn fixed_leaf_page(folder: &Path, tree: &str, len: usize, key: u64) -> u64 {
    inspect(folder, |read| {
        let root = catalog::lookup(read, tree).unwrap().unwrap().root;
        fixed::leaf_of(read, root, len, key).unwrap()
    })
}

/// The number of levels of the fixed-size tree `tree`, of values of `len` bytes, of the closed store.
pub fn fixed_height(folder: &Path, tree: &str, len: usize) -> u8 {
    inspect(folder, |read| {
        let root = catalog::lookup(read, tree).unwrap().unwrap().root;
        fixed::height(read, root, len).unwrap()
    })
}

/// Flips a byte of `page` in the closed store's data file, so that its checksum fails.
pub fn damage(folder: &Path, page: u64) {
    let path = folder.join(DATA_FILE);
    let mut bytes = fs::read(&path).unwrap();
    bytes[page as usize * PAGE_SIZE + 100] ^= 0xFF;
    fs::write(&path, bytes).unwrap();
}

#[track_caller]
pub fn damaged_page(error: Error) -> u64 {
    match error {
        Error::Damaged {
            page: Some(page), ..
        } => page,
        other => panic!("expected damage with a page, got {other}"),
    }
}

/// Checks a scan that must fail with damage of `page`: the items it returns from one end until then, owned with
/// `own`, are the next ones of `expected` from that end, and after the failure nothing more comes out of either end
/// (R8).
#[track_caller]
pub fn scan_fails_at<I, T: PartialEq + std::fmt::Debug>(
    mut scan: impl DoubleEndedIterator<Item = Result<I>>,
    expected: &[T],
    own: impl Fn(I) -> T,
    front: bool,
    page: u64,
) {
    let mut expected: Box<dyn Iterator<Item = &T>> = if front {
        Box::new(expected.iter())
    } else {
        Box::new(expected.iter().rev())
    };
    loop {
        let step = if front { scan.next() } else { scan.next_back() };
        match step.expect("the scan fails before it ends") {
            Ok(item) => assert_eq!(own(item), *expected.next().unwrap(), "front {front}"),
            Err(error) => {
                assert_eq!(damaged_page(error), page, "front {front}");
                assert!(
                    scan.next().is_none() && scan.next_back().is_none(),
                    "the scan ends"
                );
                return;
            }
        }
    }
}

/// A key of `len` bytes that starts with `i`, so that keys sort by `i`.
pub fn long_key(i: usize, len: usize) -> Vec<u8> {
    let mut key = format!("{i:05}").into_bytes();
    key.resize(len, b'.');
    key
}
