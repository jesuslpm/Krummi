use std::{borrow::Cow,sync::Arc};
use krummi::{Column,Schema,Store,StoreOptions,TableMode};
use krummi::ids::Ulid;
use krummi::table::{Projection,Col,TextBytes,Bytes,Timestamp,ProjectionError};
use krummi::table::value::{ColumnType as C,Value as V};
#[test]
fn prepared_shared_versions_defaults_nulls_owned_and_errors() {
    fn send_sync<T:Send+Sync>(){} send_sync::<Projection>();send_sync::<Col<i64>>();send_sync::<krummi::table::ProjectedRow<'static,'static>>();
    let store=Store::open_temporary(&StoreOptions::default()).unwrap();
    let schema=Schema::new(vec![Column::new("id",C::Ulid).not_null(),Column::new("text",C::String),Column::new("n",C::I64),Column::new("x",C::F64),Column::new("ts",C::Timestamp),Column::new("flag",C::Bool),Column::new("bytes",C::Bytes)],&["id"]);
    let mut w=store.write().unwrap();let t=w.open_table_with("t",TableMode::CreateNew(&schema)).unwrap();
    w.insert_row(&t,&[("id",V::Ulid(Ulid([1;16]))),("text",V::String(Cow::Borrowed("old"))),("bytes",V::Bytes(Cow::Borrowed(b"bytes"))),("x",V::F64(1.25)),("ts",V::Timestamp(-125000)),("flag",V::Bool(true))]).unwrap();w.commit().unwrap();
    let oldtx=store.read().unwrap();let oldtable=oldtx.open_table("t").unwrap();let oldp=oldtable.projection(&["id","n"]).unwrap();
    let mut w=store.write().unwrap();let t=w.open_table("t").unwrap();
    w.add_column(&t,&Column::new("added",C::String).not_null().with_default(V::String(Cow::Borrowed("catalog text")))).unwrap();
    w.add_column(&t,&Column::new("num",C::I64).not_null().with_default(V::I64(-900))).unwrap();
    w.add_column(&t,&Column::new("data",C::Bytes).with_default(V::Bytes(Cow::Borrowed(b"catalog bytes")))).unwrap();
    w.insert_row(&t,&[("id",V::Ulid(Ulid([2;16]))),("n",V::I64(77)),("added",V::String(Cow::Borrowed("new")))]).unwrap();w.commit().unwrap();
    let tx=store.read().unwrap();let t=tx.open_table("t").unwrap();
    let names=["id","n","text","bytes","x","ts","flag","added","num","data"];
    let p=t.projection(&names).unwrap();let again=t.projection(&names).unwrap();assert!(Arc::ptr_eq(&p,&again));
    let tx2=store.read().unwrap();let t2=tx2.open_table("t").unwrap();assert!(Arc::ptr_eq(&p,&t2.projection(&names).unwrap()));
    let n=p.column::<i64>(1).unwrap();let text=p.column::<TextBytes>(2).unwrap();let bytes=p.column::<Bytes>(3).unwrap();
    let x=p.column::<f64>(4).unwrap();let ts=p.column::<Timestamp>(5).unwrap();let flag=p.column::<bool>(6).unwrap();
    assert!(matches!(t.projection(&["missing"]),Err(ProjectionError::UnknownColumn(_))));
    assert!(matches!(p.column::<i64>(2),Err(ProjectionError::WrongType)));assert!(matches!(p.column::<i64>(99),Err(ProjectionError::Index)));
    let old=tx.get_row(&t,&[V::Ulid(Ulid([1;16]))]).unwrap().unwrap();let new=tx2.get_row(&t2,&[V::Ulid(Ulid([2;16]))]).unwrap().unwrap();
    for row in [&old,&new,&old] {
        let r=p.read(row).unwrap();assert_eq!(r.get(&n).unwrap(),row.i64(2));assert_eq!(r.i64(1).unwrap(),row.i64(2));
        assert_eq!(r.get(&x).unwrap(),row.f64(3));assert_eq!(r.get(&ts).unwrap(),row.timestamp(4));assert_eq!(r.get(&flag).unwrap(),row.bool(5));
        assert_eq!(r.get(&text).unwrap(),row.text_bytes(1).as_deref());assert_eq!(r.get(&bytes).unwrap(),row.bytes(6).as_deref());
        for (a,b) in [(r.text_bytes(7).unwrap().unwrap(),row.text_bytes(7).unwrap()),(r.bytes(9).unwrap().unwrap(),row.bytes(9).unwrap())] {assert_eq!(a.as_ptr(),b.as_ptr());assert_eq!(a,b.as_ref());}
        assert_eq!(r.i64(8).unwrap(),Some(-900));assert!(matches!(r.i64(2),Err(ProjectionError::WrongType)));assert!(matches!(r.i64(99),Err(ProjectionError::Index)));
    }
    assert!(matches!(oldp.read(&new),Err(ProjectionError::WrongSchema)));
    let oldschema=oldtx.get_row(&oldtable,&[V::Ulid(Ulid([1;16]))]).unwrap().unwrap();assert!(matches!(p.read(&oldschema),Err(ProjectionError::WrongSchema)));
    let reordered=t.projection(&["n","id"]).unwrap();let othercol=reordered.column::<i64>(0).unwrap();assert!(matches!(p.read(&old).unwrap().get(&othercol),Err(ProjectionError::WrongProjection)));
    let owned=old.into_owned();let r=p.read(&owned).unwrap();assert_eq!(r.text_bytes(2).unwrap(),Some(&b"old"[..]));assert_eq!(r.i64(8).unwrap(),Some(-900));
    let mut w=store.write().unwrap();let wt=w.open_table("t").unwrap();w.update_row(&wt,&[("id",V::Ulid(Ulid([1;16]))),("n",V::I64(999))]).unwrap();
    let wr=w.get_row(&wt,&[V::Ulid(Ulid([1;16]))]).unwrap().unwrap();assert_eq!(p.read(&wr).unwrap().i64(1).unwrap(),Some(999));let detached=wr.into_owned();w.abort();assert_eq!(p.read(&detached).unwrap().i64(1).unwrap(),Some(999));
    std::thread::scope(|s| {for _ in 0..4 {s.spawn(||{let tx=store.read().unwrap();let t=tx.open_table("t").unwrap();let shared=t.projection(&names).unwrap();assert!(Arc::ptr_eq(&p,&shared));let row=tx.get_row(&t,&[V::Ulid(Ulid([1;16]))]).unwrap().unwrap();assert_eq!(shared.read(&row).unwrap().i64(8).unwrap(),Some(-900));});}});
}
#[test]
fn aborted_schema_state_is_not_reused_by_a_shared_projection() {
    let store=Store::open_temporary(&StoreOptions::default()).unwrap();let schema=Schema::new(vec![Column::new("id",C::I64).not_null()],&["id"]);
    let mut w=store.write().unwrap();let t=w.open_table_with("a",TableMode::CreateNew(&schema)).unwrap();w.insert_row(&t,&[("id",V::I64(1))]).unwrap();w.commit().unwrap();
    let mut w=store.write().unwrap();let t=w.open_table("a").unwrap();w.add_column(&t,&Column::new("extra",C::I64)).unwrap();let state=w.describe_table("a").unwrap().schema_state();let aborted=w.get_row(&t,&[V::I64(1)]).unwrap().unwrap().into_owned();w.abort();
    let mut id=state;
    krummi::table::testing::with_identity_source(move |bytes|{bytes.copy_from_slice(&id.to_le_bytes());id=id.wrapping_add(1);Ok(())},||{let mut w=store.write().unwrap();let t=w.open_table("a").unwrap();w.add_column(&t,&Column::new("extra",C::I64)).unwrap();assert_ne!(w.describe_table("a").unwrap().schema_state(),state);w.commit().unwrap();});
    let tx=store.read().unwrap();let t=tx.open_table("a").unwrap();let p=t.projection(&["id"]).unwrap();assert!(matches!(p.read(&aborted),Err(ProjectionError::WrongSchema)));
}
#[test]
fn deleted_table_identity_is_reserved_while_the_cache_keeps_it() {
    let store=Store::open_temporary(&StoreOptions::default()).unwrap();
    let schema=Schema::new(vec![Column::new("id",C::I64).not_null()],&["id"]);
    let mut w=store.write().unwrap();w.open_table_with("same",TableMode::CreateNew(&schema)).unwrap();w.commit().unwrap();
    let tx=store.read().unwrap();let t=tx.open_table("same").unwrap();let p=t.projection(&["id"]).unwrap();let id=tx.describe_table("same").unwrap().table_id();
    let mut w=store.write().unwrap();w.delete_table("same").unwrap();w.commit().unwrap();
    let mut value=id;
    krummi::table::testing::with_identity_source(move |bytes| {bytes.copy_from_slice(&value.to_le_bytes());value=value.wrapping_add(1);Ok(())},|| {
        let mut w=store.write().unwrap();let t=w.open_table_with("same",TableMode::CreateNew(&schema)).unwrap();assert_ne!(w.describe_table("same").unwrap().table_id(),id);w.insert_row(&t,&[("id",V::I64(1))]).unwrap();w.commit().unwrap();
    });
    let tx=store.read().unwrap();let t=tx.open_table("same").unwrap();let row=tx.get_row(&t,&[V::I64(1)]).unwrap().unwrap();assert!(matches!(p.read(&row),Err(ProjectionError::WrongSchema)));
}
#[test]
fn variable_offset_widths_composite_keys_and_table_recreation() {
    let store=Store::open_temporary(&StoreOptions::default()).unwrap();
    let schema=Schema::new(vec![Column::new("id",C::Ulid).not_null(),Column::new("part",C::I64).not_null(),Column::new("first",C::Bytes),Column::new("last",C::String)],&["part","id"]);
    let mut w=store.write().unwrap();let t=w.open_table_with("v",TableMode::CreateNew(&schema)).unwrap();
    for (i,len) in [2usize,1000,70000].into_iter().enumerate() {w.insert_row(&t,&[("id",V::Ulid(Ulid([i as u8;16]))),("part",V::I64(-42)),("first",V::Bytes(Cow::Owned(vec![i as u8;len]))),("last",V::String(Cow::Borrowed("tail")))]).unwrap();}w.commit().unwrap();
    let tx=store.read().unwrap();let t=tx.open_table("v").unwrap();let p=t.projection(&["last","id","first","part"]).unwrap();
    for (i,len) in [2usize,1000,70000].into_iter().enumerate() {let row=tx.get_row(&t,&[V::I64(-42),V::Ulid(Ulid([i as u8;16]))]).unwrap().unwrap();let r=p.read(&row).unwrap();assert_eq!(r.text_bytes(0).unwrap(),Some(&b"tail"[..]));assert_eq!(r.bytes(2).unwrap().unwrap().len(),len);assert_eq!(r.bytes(2).unwrap().unwrap().as_ptr(),row.bytes(2).unwrap().as_ptr());assert_eq!(r.i64(3).unwrap(),Some(-42));assert_eq!(r.ulid(1).unwrap(),Some(Ulid([i as u8;16])));}
    let mut w=store.write().unwrap();w.delete_table("v").unwrap();let t=w.open_table_with("v",TableMode::CreateNew(&schema)).unwrap();w.insert_row(&t,&[("id",V::Ulid(Ulid([0;16]))),("part",V::I64(-42))]).unwrap();w.commit().unwrap();
    let newer=store.read().unwrap();let t=newer.open_table("v").unwrap();let row=newer.get_row(&t,&[V::I64(-42),V::Ulid(Ulid([0;16]))]).unwrap().unwrap();assert!(matches!(p.read(&row),Err(ProjectionError::WrongSchema)));
}
