//! Time and space of multi-value trees with each candidate pair of thresholds (decision M15 of the multi-value trees
//! PRD, whose data feeds the choice of the thresholds, M3, and is checked by criteria AC-M19 and AC-M20).
//!
//! ```text
//! cargo run --release -p krummi --example multi_timing [options]
//! ```
//!
//! Options:
//!
//! - `--folder <path>`: where the stores live, each in its own temporary folder (the system's temporary folder by
//!   default).
//! - `--pairs <p:d,...>`: the threshold pairs, promotion and demotion in bytes of volume, `max` standing for
//!   [`MAX_PROMOTION`] (the six of M3 below by default).
//! - `--loads <name,...>`: the loads to run, of `n1`, `n10`, `n100`, `n1000`, `n10000`, `n100000`, `n1000000`,
//!   `zipf` and `oscillating` (all by default), so that a run can be split.
//! - `--values <count>`: values per load (1,000,000 by default, as M15 sets); the skewed load spreads them over a
//!   tenth as many keys and the oscillating load makes a tenth as many operations, so the default is M15's load.
//!   A set size above the count is skipped, and one that does not divide it takes the whole sets that fit.
//! - `--key-size <bytes>`: the length of the keys, at least 16 bytes (16 by default, as M15 sets).
//! - `--value-size <bytes>`: the length of the values, at least 8 bytes (16 by default, as M15 sets). The baseline's
//!   key is the key followed by the value, so the two together are at most 2,048 bytes.
//! - `--quick`: a smoke test, the same as `--values 10000`.
//!
//! Every store is on disk and commits durably; keys and values are random strings with fixed seeds, of 16 bytes or of
//! the lengths the options give. The measurement is run by hand: neither the tests nor the CI run it. Before
//! each load the thresholds are set with the measurement hook of the engine (D7). The loads (M15):
//!
//! - **By set size**: the values spread over keys of N values each, for N = 1, 10, 100, 1,000, 10,000, 100,000 and
//!   1,000,000.
//! - **Skewed**: each value goes to a key chosen at random among a tenth as many keys (100,000) with a Zipf
//!   distribution of exponent 1.
//!
//!   For each of them, in a new store: add every value in a random order that interleaves the keys, in writes of
//!   1,000 values; the store's size (P12) after the last commit; then, closed and reopened without dropping the
//!   system's cache, check every value at random with Contains in a single read transaction, scan the keys of the
//!   whole tree, and scan the values of every key, reading every byte, each in its own read transaction; and remove
//!   every value at random with Remove value, in writes of 1,000. It also prints the store's size after the
//!   removals, the pages in use after the adds (the store's pages but the free ones, finer than the size, which
//!   grows in steps), and the pages a Contains reads on average: each lookup reads one page per level of the tree, and for
//!   a key in a subtree one more per level of the subtree, so the average comes from the heights of the closed store.
//!
//!   Each of these loads also has a baseline row, `composite`: the same values in a normal tree whose keys are the
//!   key followed by the value, with empty values, added with Try add, checked with Get, scanned with a prefix scan
//!   per key and removed with Remove. It has no key scan.
//! - **Oscillating**: in a new store, one key with the most values whose volume does not exceed the promotion
//!   threshold, so that the next Add exceeds it; then a tenth as many operations as values (100,000), alternating,
//!   from an Add, an Add of a new value and a Remove value of that same value, in writes of 1,000 operations: the
//!   time, the store's size after the last commit, and whether the key ends in a subtree.
//!
//! The candidate pairs (M3), in bytes of volume (the key's length plus its inline blob: 3 bytes and, per value, 2
//! bytes and its bytes, D2), so that with 16-byte keys and values a key of `n` values has a volume of `19 + 18n`:
//!
//! | Promotion | Values inline at most | Demotion close (7/8) | Demotion about half |
//! |---|---|---|---|
//! | 512, low | 27 | 448 | 256 |
//! | 2,048, intermediate | 112 | 1,792 | 1,024 |
//! | [`MAX_PROMOTION`] (4,074), high (the default): an inline entry fills the longest leaf cell | 225 | 3,564 | 2,037 |
//!
//! The low promotion moves keys of 100 values to subtrees and keeps keys of 10 inline; the intermediate and the high
//! keep keys of 100 inline too, with a quarter and a half of a leaf. The close demotion is 64 bytes, three and a half
//! values, below the low promotion and proportionally below the others.
//!
//! It prints a header with the operating system and the architecture, and a Markdown table per load with a row per
//! pair; durations are in milliseconds. The processor and the disk go in the report by hand. The results go in the
//! closing report of the multi-value trees execution, with the evaluation of M3. No time is a pass mark (D5 of the
//! root PRD).

// The measurement shares the tree measurements' helpers, of which it uses only some.
#[allow(dead_code)]
mod timing;

use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use krummi::{OpenMode, Store, StoreOptions};
use krummi_tree::multi::{self, MAX_PROMOTION, multi_thresholds, set_multi_thresholds, volume};
use krummi_tree::{MAX_KEY, catalog};
use krummi_tx::{Engine, OpenOptions as EngineOptions};
use timing::{BATCH, KEY, TREE, shuffled, splitmix};

/// Values per load, as M15 sets them.
const VALUES: usize = 1_000_000;
/// Values per load with `--quick`.
const QUICK: usize = 10_000;
/// The set sizes of the loads by set size.
const SET_SIZES: [usize; 7] = [1, 10, 100, 1_000, 10_000, 100_000, 1_000_000];
/// The candidate promotion thresholds of M3: low, intermediate and high.
const PROMOTIONS: [usize; 3] = [512, 2048, MAX_PROMOTION];

/// A load of M15.
#[derive(Clone, Copy, PartialEq)]
enum Load {
    /// Keys of this many values each.
    SetSize(usize),
    /// Values spread over keys with a Zipf distribution of exponent 1.
    Zipf,
    /// One key at the promotion threshold, with Add and Remove value alternating.
    Oscillating,
}

impl Load {
    fn name(self) -> String {
        match self {
            Load::SetSize(n) => format!("n{n}"),
            Load::Zipf => "zipf".into(),
            Load::Oscillating => "oscillating".into(),
        }
    }
}

/// The values of a load and the key of each.
struct Data {
    keys: Vec<Vec<u8>>,
    values: Vec<Vec<u8>>,
    /// The index in `keys` of the key of each value.
    owner: Vec<u32>,
    /// The indexes of the keys with values, in the keys' byte order, and their number of values.
    used: Vec<(usize, u64)>,
}

/// How a load is stored.
#[derive(Clone, Copy, PartialEq)]
enum Shape {
    /// In a multi-value tree, with the thresholds in force.
    Multi,
    /// The baseline: in a normal tree whose keys are the key followed by the value, with empty values.
    Composite,
}

/// What a load by set size or the skewed load measures with one pair, or with the baseline.
struct Measured {
    add: Duration,
    size: u64,
    /// The store's pages but the free ones after the adds: the size grows in steps, these tell the space finely.
    in_use: u64,
    pages: f64,
    contains: Duration,
    /// The key scan; the baseline has none.
    keys: Option<Duration>,
    values: Duration,
    remove: Duration,
    emptied: u64,
}

impl Measured {
    fn row(&self, label: &str, count: usize) {
        println!(
            "| {label} | {} | {:.2} | {} | {} | {:.2} | {} | {} | {} | {} | {} |",
            ms(self.add),
            self.add.as_secs_f64() * 1e6 / count as f64,
            self.size,
            self.in_use,
            self.pages,
            ms(self.contains),
            self.keys.map_or("—".into(), ms),
            ms(self.values),
            ms(self.remove),
            self.emptied,
        );
    }
}

fn main() {
    let options = Options::parse();
    println!("# Multi-value trees measurement (M15)");
    println!();
    println!(
        "- OS: {}, architecture: {}; processor and disk: fill in by hand.",
        std::env::consts::OS,
        std::env::consts::ARCH
    );
    println!(
        "- Values per load: {}; writes of {BATCH}; keys of {} bytes and values of {} bytes; MAX_PROMOTION = {MAX_PROMOTION}.",
        options.values, options.key_size, options.value_size
    );
    println!(
        "- Pairs (promotion:demotion): {}.",
        pairs_label(&options.pairs)
    );

    for &load in &options.loads {
        println!();
        match load {
            Load::SetSize(n) if n > options.values => {
                println!(
                    "## Load {}: skipped, {n} values per key exceed the {} values of the load",
                    load.name(),
                    options.values
                );
            }
            Load::SetSize(_) | Load::Zipf => {
                let data = data(load, options.values, options.key_size, options.value_size);
                println!(
                    "## Load {}: {} values, keys with values: {}",
                    load.name(),
                    data.values.len(),
                    data.used.len()
                );
                println!();
                println!(
                    "| Promotion:demotion | Add (ms) | µs per add | Size after add (bytes) | Pages in use after add | Pages per Contains | Contains (ms) | Scan keys (ms) | Scan values (ms) | Remove (ms) | Size after remove (bytes) |"
                );
                println!("|---|---|---|---|---|---|---|---|---|---|---|");
                for &(promotion, demotion) in &options.pairs {
                    set_multi_thresholds(promotion, demotion);
                    measure(&options.folder, &data, Shape::Multi)
                        .row(&format!("{promotion}:{demotion}"), data.values.len());
                }
                measure(&options.folder, &data, Shape::Composite)
                    .row("composite", data.values.len());
            }
            Load::Oscillating => {
                let operations = options.values / 10;
                println!(
                    "## Load oscillating: {operations} operations on one key at the promotion threshold"
                );
                println!();
                println!(
                    "| Promotion:demotion | Values at the threshold | Time (ms) | µs per operation | Size (bytes) | Ends in a subtree |"
                );
                println!("|---|---|---|---|---|---|");
                for &(promotion, demotion) in &options.pairs {
                    set_multi_thresholds(promotion, demotion);
                    let (at_threshold, elapsed, size, subtree) = oscillate(
                        &options.folder,
                        operations,
                        options.key_size,
                        options.value_size,
                    );
                    println!(
                        "| {promotion}:{demotion} | {at_threshold} | {} | {:.2} | {size} | {} |",
                        ms(elapsed),
                        elapsed.as_secs_f64() * 1e6 / operations.max(1) as f64,
                        if subtree { "yes" } else { "no" },
                    );
                }
            }
        }
    }
}

/// The options of the command line.
struct Options {
    folder: PathBuf,
    pairs: Vec<(usize, usize)>,
    loads: Vec<Load>,
    values: usize,
    key_size: usize,
    value_size: usize,
}

impl Options {
    fn parse() -> Self {
        let mut options = Options {
            folder: std::env::temp_dir(),
            pairs: PROMOTIONS
                .iter()
                .flat_map(|&p| [(p, p * 7 / 8), (p, p / 2)])
                .collect(),
            loads: all_loads(),
            values: VALUES,
            key_size: KEY,
            value_size: KEY,
        };
        let mut args = std::env::args().skip(1);
        while let Some(arg) = args.next() {
            let mut value = || {
                args.next()
                    .unwrap_or_else(|| usage(&format!("{arg} needs a value")))
            };
            match arg.as_str() {
                "--folder" => options.folder = value().into(),
                "--pairs" => options.pairs = parse_pairs(&value()),
                "--loads" => options.loads = parse_loads(&value()),
                "--values" => {
                    options.values = value()
                        .parse()
                        .ok()
                        .filter(|&v| v > 0)
                        .unwrap_or_else(|| usage("--values takes a positive count"));
                }
                "--key-size" => {
                    options.key_size =
                        value()
                            .parse()
                            .ok()
                            .filter(|&k| k >= KEY)
                            .unwrap_or_else(|| {
                                usage(&format!("--key-size takes at least {KEY} bytes"))
                            });
                }
                "--value-size" => {
                    options.value_size = value()
                        .parse()
                        .ok()
                        .filter(|&v| v >= 8)
                        .unwrap_or_else(|| usage("--value-size takes at least 8 bytes"));
                }
                "--quick" => options.values = QUICK,
                "--help" | "-h" => usage(""),
                other => usage(&format!("unknown option {other}")),
            }
        }
        if options.key_size + options.value_size > MAX_KEY {
            usage(&format!(
                "a key and a value of {} bytes in all exceed the {MAX_KEY} of the baseline's key",
                options.key_size + options.value_size
            ));
        }
        options
    }
}

fn all_loads() -> Vec<Load> {
    SET_SIZES
        .iter()
        .map(|&n| Load::SetSize(n))
        .chain([Load::Zipf, Load::Oscillating])
        .collect()
}

fn parse_loads(list: &str) -> Vec<Load> {
    list.split(',')
        .map(|name| {
            all_loads()
                .into_iter()
                .find(|load| load.name() == name.trim())
                .unwrap_or_else(|| usage(&format!("unknown load {name}")))
        })
        .collect()
}

/// Pairs `promotion:demotion`, each satisfying `demotion < promotion <= MAX_PROMOTION`.
fn parse_pairs(list: &str) -> Vec<(usize, usize)> {
    let threshold = |s: &str| match s.trim() {
        "max" => Some(MAX_PROMOTION),
        s => s.parse().ok(),
    };
    list.split(',')
        .map(|pair| {
            pair.split_once(':')
                .and_then(|(p, d)| Some((threshold(p)?, threshold(d)?)))
                .filter(|&(p, d)| d < p && p <= MAX_PROMOTION)
                .unwrap_or_else(|| {
                    usage(&format!(
                        "pair {pair} is not promotion:demotion with demotion < promotion <= {MAX_PROMOTION}"
                    ))
                })
        })
        .collect()
}

fn pairs_label(pairs: &[(usize, usize)]) -> String {
    pairs
        .iter()
        .map(|(p, d)| format!("{p}:{d}"))
        .collect::<Vec<_>>()
        .join(", ")
}

fn usage(error: &str) -> ! {
    if !error.is_empty() {
        eprintln!("error: {error}");
    }
    eprintln!(
        "usage: multi_timing [--folder <path>] [--pairs <p:d,...>] [--loads <name,...>] [--values <count>] [--key-size <bytes>] [--value-size <bytes>] [--quick]"
    );
    eprintln!(
        "loads: {}",
        all_loads()
            .iter()
            .map(|l| l.name())
            .collect::<Vec<_>>()
            .join(", ")
    );
    std::process::exit(if error.is_empty() { 0 } else { 2 })
}

/// The keys and values of a load by set size or of the skewed load, with `count` values; by set size, only the whole
/// sets that fit in `count`; the keys have `key_size` bytes and the values `value_size`.
fn data(load: Load, count: usize, key_size: usize, value_size: usize) -> Data {
    let count = match load {
        Load::SetSize(n) => count / n * n,
        _ => count,
    };
    let values = random_values(count, value_size);
    let (key_count, owner): (usize, Vec<u32>) = match load {
        Load::SetSize(n) => (count / n, (0..count).map(|j| (j / n) as u32).collect()),
        Load::Zipf => {
            let key_count = (count / 10).max(1);
            (key_count, zipf(key_count, count, 0x5EED_0102))
        }
        Load::Oscillating => unreachable!("the oscillating load has its own data"),
    };
    let keys = random_keys(key_count, key_size);
    let mut counts = vec![0u64; key_count];
    for &k in &owner {
        counts[k as usize] += 1;
    }
    let mut used: Vec<(usize, u64)> = counts
        .into_iter()
        .enumerate()
        .filter(|&(_, n)| n > 0)
        .collect();
    used.sort_unstable_by(|a, b| keys[a.0].cmp(&keys[b.0]));
    Data {
        keys,
        values,
        owner,
        used,
    }
}

/// `count` distinct random values of `size` bytes, at least 8: with 16 or more, [`timing::keys`] followed by random
/// bytes; with fewer, their first bytes, a bijection of the index. With 16 bytes they are those of M15's runs.
fn random_values(count: usize, size: usize) -> Vec<Vec<u8>> {
    timing::keys(count)
        .into_iter()
        .enumerate()
        .map(|(i, start)| {
            let mut value = start[..size.min(KEY)].to_vec();
            let mut state = (i as u64).wrapping_add(0x5EED_0106);
            while value.len() < size {
                let word = splitmix(state).to_be_bytes();
                let take = word.len().min(size - value.len());
                value.extend_from_slice(&word[..take]);
                state = state.wrapping_add(0x9E37_79B9_7F4A_7C15);
            }
            value
        })
        .collect()
}

/// `count` distinct random keys of `size` bytes, at least 16, other than the values that [`timing::keys`] gives: the
/// first 8 bytes are a bijection of the index, and the rest random. With 16 bytes they are those of M15's runs.
fn random_keys(count: usize, size: usize) -> Vec<Vec<u8>> {
    (0..count as u64)
        .map(|i| {
            let mut key = Vec::with_capacity(size);
            key.extend_from_slice(&splitmix(i ^ 0x5EED_0101).to_be_bytes());
            let mut state = i.wrapping_add(0x5EED_0103);
            while key.len() < size {
                let word = splitmix(state).to_be_bytes();
                let take = word.len().min(size - key.len());
                key.extend_from_slice(&word[..take]);
                state = state.wrapping_add(0x9E37_79B9_7F4A_7C15);
            }
            key
        })
        .collect()
}

/// `samples` key indexes among `keys`, index `k` drawn with a weight of `1 / (k + 1)` (Zipf, exponent 1), from a
/// fixed `seed`: inverse transform over the cumulative weights.
fn zipf(keys: usize, samples: usize, seed: u64) -> Vec<u32> {
    let cumulative: Vec<f64> = (1..=keys)
        .scan(0.0, |sum, k| {
            *sum += 1.0 / k as f64;
            Some(*sum)
        })
        .collect();
    let total = cumulative[keys - 1];
    let mut state = seed;
    (0..samples)
        .map(|_| {
            state = splitmix(state);
            // 53 random bits, a uniform number in [0, 1).
            let u = (state >> 11) as f64 / (1u64 << 53) as f64 * total;
            cumulative.partition_point(|&c| c <= u).min(keys - 1) as u32
        })
        .collect()
}

/// Runs a load by set size or the skewed load in a new store inside `base`, as `shape` says, with the thresholds in
/// force.
fn measure(base: &Path, data: &Data, shape: Shape) -> Measured {
    let folder = tempfile::tempdir_in(base).expect("a temporary folder");
    let count = data.values.len();
    let key_of = |j: usize| &data.keys[data.owner[j] as usize];
    let composite_of = |j: usize| composite(key_of(j), &data.values[j]);

    let store = Store::open(folder.path(), &StoreOptions::default()).expect("open");
    let order = shuffled(count, 0x5EED_0104);
    let start = Instant::now();
    for chunk in order.chunks(BATCH) {
        let mut write = store.write().expect("write");
        match shape {
            Shape::Multi => {
                let tree = write
                    .open_multi_tree_with(TREE, OpenMode::OpenOrCreate)
                    .expect("open or create the tree");
                for &j in chunk {
                    let added = write.add(&tree, key_of(j), &data.values[j]).expect("add");
                    assert!(added, "value {j} is new");
                }
            }
            Shape::Composite => {
                let tree = write
                    .open_tree_with(TREE, OpenMode::OpenOrCreate)
                    .expect("open or create the tree");
                for &j in chunk {
                    let added = write
                        .try_add(&tree, &composite_of(j), b"")
                        .expect("try add");
                    assert!(added, "value {j} is new");
                }
            }
        }
        write.commit().expect("commit");
    }
    let add = start.elapsed();
    let info = store.info();
    let (size, in_use) = (info.size_bytes, info.page_count - info.free_pages);
    store.close().expect("close");
    let pages = pages_per_contains(folder.path(), data, shape);

    let store = Store::open(folder.path(), &StoreOptions::default()).expect("reopen");
    let contains = {
        let read = store.read().expect("read");
        let order = shuffled(count, 0x5EED_0105);
        let start = Instant::now();
        match shape {
            Shape::Multi => {
                let tree = read.open_multi_tree(TREE).expect("open the tree");
                for &j in &order {
                    let found = read
                        .contains(&tree, key_of(j), &data.values[j])
                        .expect("contains");
                    assert!(found, "value {j} is there");
                }
            }
            Shape::Composite => {
                let tree = read.open_tree(TREE).expect("open the tree");
                for &j in &order {
                    let found = read.get(&tree, &composite_of(j)).expect("get");
                    assert!(found.is_some(), "value {j} is there");
                }
            }
        }
        start.elapsed()
    };
    let keys = (shape == Shape::Multi).then(|| {
        let read = store.read().expect("read");
        let tree = read.open_multi_tree(TREE).expect("open the tree");
        let start = Instant::now();
        let (mut scanned, mut values, mut sum) = (0, 0, 0u64);
        for entry in read.keys(&tree, ..).expect("scan the keys") {
            let (key, n) = entry.expect("a key");
            scanned += 1;
            values += n;
            sum = checksum(sum, key);
        }
        let elapsed = start.elapsed();
        std::hint::black_box(sum);
        assert_eq!((scanned, values), (data.used.len(), count as u64));
        elapsed
    });
    let values = {
        let read = store.read().expect("read");
        let start = Instant::now();
        let mut sum = 0u64;
        for &(k, expected) in &data.used {
            let key = &data.keys[k];
            let mut scanned = 0;
            match shape {
                Shape::Multi => {
                    let tree = read.open_multi_tree(TREE).expect("open the tree");
                    for value in read.values(&tree, key, ..).expect("scan the values") {
                        sum = checksum(sum, value.expect("a value"));
                        scanned += 1;
                    }
                }
                Shape::Composite => {
                    let tree = read.open_tree(TREE).expect("open the tree");
                    for entry in read.range_prefix(&tree, key, ..).expect("scan the prefix") {
                        sum = checksum(sum, &entry.expect("an entry").0[key.len()..]);
                        scanned += 1;
                    }
                }
            }
            assert_eq!(scanned, expected, "the values of key {k}");
        }
        let elapsed = start.elapsed();
        std::hint::black_box(sum);
        elapsed
    };

    let order = shuffled(count, 0x5EED_0106);
    let start = Instant::now();
    for chunk in order.chunks(BATCH) {
        let mut write = store.write().expect("write");
        match shape {
            Shape::Multi => {
                let tree = write.open_multi_tree(TREE).expect("open the tree");
                for &j in chunk {
                    let removed = write
                        .remove_value(&tree, key_of(j), &data.values[j])
                        .expect("remove value");
                    assert!(removed, "value {j} was there");
                }
            }
            Shape::Composite => {
                let tree = write.open_tree(TREE).expect("open the tree");
                for &j in chunk {
                    let removed = write.remove(&tree, &composite_of(j)).expect("remove");
                    assert!(removed, "value {j} was there");
                }
            }
        }
        write.commit().expect("commit");
    }
    let remove = start.elapsed();
    let emptied = store.info().size_bytes;
    store.close().expect("close");

    Measured {
        add,
        size,
        in_use,
        pages,
        contains,
        keys,
        values,
        remove,
        emptied,
    }
}

/// The key of the baseline for `value` of `key`: the key followed by the value.
fn composite(key: &[u8], value: &[u8]) -> Vec<u8> {
    [key, value].concat()
}

/// The pages a Contains reads on average over every value of the closed store in `folder`: one per level of the tree,
/// and, for a value of a key in a subtree, one more per level of the subtree.
fn pages_per_contains(folder: &Path, data: &Data, shape: Shape) -> f64 {
    let engine = Engine::open(folder, &EngineOptions::default()).expect("open the engine");
    let read = engine.read().expect("read");
    let root = catalog::lookup(&read, TREE)
        .expect("the catalog")
        .expect("the tree")
        .root;
    let mut levels =
        u64::from(krummi_tree::height(&read, root).expect("the height")) * data.values.len() as u64;
    if shape == Shape::Multi {
        for &(k, n) in &data.used {
            if let Some(subtree) =
                multi::subtree_of(&read, root, &data.keys[k]).expect("the subtree")
            {
                levels += n * u64::from(krummi_tree::height(&read, subtree).expect("the height"));
            }
        }
    }
    drop(read);
    engine.close().expect("close the engine");
    levels as f64 / data.values.len() as f64
}

/// Runs the oscillating load in a new store inside `base`, with the thresholds in force: returns the values of the
/// key at the threshold, the time of the `operations`, the store's size after the last commit and whether the key
/// ends in a subtree.
fn oscillate(
    base: &Path,
    operations: usize,
    key_size: usize,
    value_size: usize,
) -> (usize, Duration, u64, bool) {
    let (promotion, _) = multi_thresholds();
    let mut at_threshold = 0;
    while volume(key_size, std::iter::repeat_n(value_size, at_threshold + 1)) <= promotion {
        at_threshold += 1;
    }
    let key = random_keys(1, key_size).remove(0);
    let values = random_values(at_threshold + operations.div_ceil(2), value_size);

    let folder = tempfile::tempdir_in(base).expect("a temporary folder");
    let store = Store::open(folder.path(), &StoreOptions::default()).expect("open");
    // Created on its own, since one value may already pass the threshold and leave no values before it.
    let mut write = store.write().expect("write");
    write
        .open_multi_tree_with(TREE, OpenMode::CreateNew)
        .expect("create the tree");
    write.commit().expect("commit");
    for chunk in values[..at_threshold].chunks(BATCH) {
        let mut write = store.write().expect("write");
        let tree = write.open_multi_tree(TREE).expect("open the tree");
        for value in chunk {
            assert!(write.add(&tree, &key, value).expect("add"));
        }
        write.commit().expect("commit");
    }

    let start = Instant::now();
    for first in (0..operations).step_by(BATCH) {
        let mut write = store.write().expect("write");
        let tree = write.open_multi_tree(TREE).expect("open the tree");
        for i in first..operations.min(first + BATCH) {
            let value = &values[at_threshold + i / 2];
            let changed = if i % 2 == 0 {
                write.add(&tree, &key, value).expect("add")
            } else {
                write
                    .remove_value(&tree, &key, value)
                    .expect("remove value")
            };
            assert!(changed, "operation {i} changes the key");
        }
        write.commit().expect("commit");
    }
    let elapsed = start.elapsed();
    let size = store.info().size_bytes;
    let subtree = {
        let read = store.read().expect("read");
        let tree = read.open_multi_tree(TREE).expect("open the tree");
        read.subtree_of(&tree, &key).expect("subtree of").is_some()
    };
    store.close().expect("close");
    (at_threshold, elapsed, size, subtree)
}

fn checksum(sum: u64, bytes: &[u8]) -> u64 {
    bytes.iter().fold(sum, |s, &b| s.wrapping_add(u64::from(b)))
}

/// A duration in milliseconds, for the tables.
fn ms(elapsed: Duration) -> String {
    format!("{:.1}", elapsed.as_secs_f64() * 1e3)
}
