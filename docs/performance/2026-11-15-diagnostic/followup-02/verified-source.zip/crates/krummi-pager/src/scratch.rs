//! The scratch area (module 2): committed page versions that are not in the data file yet, and the snapshots that
//! read through them (T2, T14, T16 of the Transactions PRD).
//!
//! As in Voron, every page keeps its number. A write transaction changes copies of its pages; committing publishes
//! them as the newest version of each page. A version stays here while an open snapshot still needs the version
//! before it, which may be the one in the data file; once no snapshot is older than it, it is written in place and
//! leaves the scratch area. A version that leaves stays allocated until every snapshot that may hold a reference
//! to it has ended, so references returned by [`Snapshot::page`] stay valid for the whole snapshot (D11); the
//! writer's own flush ([`ScratchWriter::flush`]) does not wait for the writer's snapshot, whose references borrow
//! the writer and so end before it (T8).
//!
//! With the journal's queue (E2, E3 of the grouped journal PRD), a commit is published for the next writer when it
//! passes its point of no return, and read snapshots see it only once it is durable: a read snapshot sees up to the
//! last durable commit, the writer's snapshot up to the last published one. The writer's snapshot sees the newest
//! version of every page, so it never keeps an older one alive; read snapshots opened later may need the newest
//! durable version of a page while a newer one is not durable yet, so that one is kept too.
//!
//! Why the shared page writes are sound: a flush writes page `n` only when every open snapshot sees the newest
//! version of `n` (none is older than it), and that version stays in the scratch area until the write ends, so
//! every snapshot reads `n` from here and nobody holds a reference into the data file's copy of `n`. Snapshots
//! that start afterwards read the newest version too. While the store is open only the transfer thread writes
//! versions in place, holding `flushing` (see the `transfer` module), so no two writes of a page overlap; the
//! close writes the rest once that thread has ended. A scratch area without the thread ([`Scratch::new`], for its
//! own tests) writes them on the caller's thread, under the same lock.
//!
//! Value runs (D5 of the large values execution) are published as one version per page, all pointing into the run's
//! contiguous slots of the temporary area, so that [`Snapshot::run`] returns the run as one sequence. A run is
//! written in place as a unit once it is the newest version of one of its pages and no snapshot is older than it:
//! all its pages, also those a later commit reused, since no snapshot reads those pages from the data file (the
//! snapshots older than the run are gone, and the newer ones find the run or a newer version here). Then every page
//! of the run drops the run's version and the ones before it, so that no snapshot finds part of a run here and the
//! rest in the data file. A pass writes in the order of the commits, so an older run never overwrites a newer
//! version of one of its pages.
//!
//! The bytes of the versions ([`Scratch::scratch_bytes`]) count for the maximum size (T14, P10). A page of its own
//! counts while its version is here; once retired it is a copy of the page in the data file, whose bytes count
//! already, so it stops counting, as before value runs. A run's slots are one allocation that any of its versions
//! keeps whole, here or retired, so the run counts whole from its first version until the last one is freed: when a
//! later run reuses all its pages but the last one, the old run's other pages are no longer in the data file, and
//! its slots are memory the engine reserved so that the run is contiguous, which counts for the maximum size (large
//! values PRD, *Dejado a la implementación*). That holds while an older snapshot keeps the newer versions here and
//! while a newer snapshot keeps the retired run allocated (R1 of the large values code review and its follow-ups).

use std::cell::Cell;
use std::collections::HashMap;
use std::marker::PhantomData;
use std::mem::size_of;
use std::path::Path;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::{Arc, Mutex, MutexGuard, PoisonError, RwLock, RwLockReadGuard, RwLockWriteGuard};
use std::thread::JoinHandle;
use std::time::Duration;

use crate::error::{Error, Result};
use crate::format::{self, Header};
use crate::format::{HEADER_PAGES, PAGE_HEADER_SIZE, PAGE_PAYLOAD_SIZE, PAGE_SIZE, PAGE_SIZE_U64};
use crate::journal::{Journal, JournalPage, RAW_ENTRY};
use crate::pager::{Info, Integrity, Pager};
use crate::recovery;
use crate::sys;
use crate::temp::{Slot, TempArea};
use crate::transfer::{self, Demand, Pacing, Signal};

/// The payload of a page being changed by a write transaction.
pub type PayloadBuf = Box<[u8; PAGE_PAYLOAD_SIZE]>;
/// A value run of whole pages (D1 of the large values execution): the run's 16-byte header, then its content. A write
/// transaction fills it and seals it with [`seal_run`](crate::format::seal_run) to publish it.
pub type RunBuf = Box<[u8]>;
/// Pages of a commit copied into the temporary area, ready to be published (J7 of the Journal PRD): each page's
/// number, its slots and its index in them.
pub struct Staged(Vec<(u64, Arc<Slot>, usize)>);

/// Where the bytes of a reference live (tests: AC20, AC-V3).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Memory {
    /// The store's pages: the mapping of `krummi.data`, or the memory of a temporary store.
    Data,
    /// The versions of the temporary area (J7).
    Versions,
}

/// A zeroed page payload, or the out-of-memory class if the system does not provide it (P13).
pub fn alloc_payload() -> Result<PayloadBuf> {
    alloc::<PAGE_PAYLOAD_SIZE>()
}

/// A payload for a copy of a page, whose bytes the caller all overwrites: `spare`, kept from an earlier commit, or
/// a zeroed one (candidate 4 of the writes diagnosis, performance plan). The out-of-memory class if the system does
/// not provide it (P13); it is the fault point of [`alloc_payload`] either way, so a reused payload fails where a
/// new one would.
pub fn reuse_payload(spare: Option<PayloadBuf>) -> Result<PayloadBuf> {
    match spare {
        Some(payload) => {
            sys::alloc_point().map_err(|_| Error::OutOfMemory {
                requested: PAGE_PAYLOAD_SIZE as u64,
            })?;
            Ok(payload)
        }
        None => alloc_payload(),
    }
}

/// A zeroed run of `pages` pages, or the out-of-memory class if the system does not provide it (P13).
pub fn alloc_run(pages: u64) -> Result<RunBuf> {
    let requested = pages.saturating_mul(PAGE_SIZE_U64);
    let out_of_memory = || Error::OutOfMemory { requested };
    let bytes = usize::try_from(requested).map_err(|_| out_of_memory())?;
    sys::alloc_zeroed(bytes).map_err(|_| out_of_memory())
}

/// Reserves room for `additional` more elements in `vec`, or fails with the out-of-memory class if the system does
/// not provide it (P13), instead of aborting the process as the infallible allocations do. The layers above reserve
/// through it the memory of their operations; it is a fault point (`Op::Alloc`) even when `vec` has room.
pub fn try_reserve<T>(vec: &mut Vec<T>, additional: usize) -> Result<()> {
    let out_of_memory = || Error::OutOfMemory {
        requested: additional.saturating_mul(size_of::<T>()) as u64,
    };
    sys::alloc_point().map_err(|_| out_of_memory())?;
    vec.try_reserve(additional).map_err(|_| out_of_memory())
}

fn alloc<const N: usize>() -> Result<Box<[u8; N]>> {
    let bytes = sys::alloc_zeroed(N).map_err(|_| Error::OutOfMemory {
        requested: N as u64,
    })?;
    Ok(bytes.try_into().expect("exactly N bytes were allocated"))
}

/// A store with its scratch area.
pub struct Scratch {
    /// What the transfer thread shares with the store.
    shared: Arc<Shared>,
    /// Held by the one [`ScratchWriter`] that may exist at a time.
    writer: Mutex<()>,
    /// The transfer thread, which every store opened with [`Scratch::open`] has (J5).
    transfers: Option<JoinHandle<()>>,
}

/// The part of a store the transfer thread uses too.
pub(crate) struct Shared {
    /// `None` only after [`Scratch::close`] took it.
    pager: Option<Pager>,
    /// Where the versions live (J7 of the Journal PRD).
    area: Arc<TempArea>,
    /// The journal of a store on disk; `None` for a temporary store (J17).
    journal: Option<Journal>,
    /// The versions and what they depend on. Reads of pages share it, so that they never wait for each other; every
    /// change takes it alone (U3 of the version checks PRD).
    state: RwLock<State>,
    /// Which pages may have versions in `state`: reads of the others skip the lock.
    filter: Arc<VersionFilter>,
    /// Held while versions are written in place, so no two writes of a page overlap (J5).
    flushing: Mutex<()>,
    /// Wakes the transfer thread.
    signal: Arc<Signal>,
    /// Called by a transfer while it holds `flushing`, once it knows what it writes (tests).
    transfer_hook: Mutex<Option<Hook>>,
    /// Called when a transfer fails outside any operation, so the transaction layer wakes its waiting requests
    /// (J13).
    failure_hook: Mutex<Option<Hook>>,
    /// Transfer passes so far (tests).
    passes: AtomicU64,
    /// Layout checks of versions reported by the layers above (tests of the version checks PRD).
    #[cfg(any(test, feature = "test-hooks"))]
    version_checks: AtomicU64,
}

type Hook = Arc<dyn Fn() + Send + Sync>;

/// Slots of a [`VersionFilter`]: 256 KiB of counters.
const FILTER_SLOTS: u64 = 1 << 16;

/// How many pages with versions in the scratch area fall in each slot of page numbers, `page % FILTER_SLOTS` (W12 of
/// the margin diagnosis, performance plan). It changes only under the state's lock, when the list of versions of a
/// page goes from empty to not and back, and a snapshot reads it without the lock: a slot at zero means that no page
/// of it has a version here, so the snapshot reads the store without taking the lock, which would have told it the
/// same. A version the snapshot can see was published before the snapshot registered, both under the lock, so its
/// count is visible to the snapshot; a count still to come is of a newer commit, which the snapshot does not see. A
/// count that falls to zero does so after the page's version was written in place and taken out under the lock, as
/// the lock would show.
struct VersionFilter(Box<[AtomicU32]>);

impl VersionFilter {
    fn new() -> VersionFilter {
        VersionFilter((0..FILTER_SLOTS).map(|_| AtomicU32::new(0)).collect())
    }

    fn slot(&self, page_number: u64) -> &AtomicU32 {
        &self.0[(page_number % FILTER_SLOTS) as usize]
    }

    /// Page `page_number` got its first version.
    fn added(&self, page_number: u64) {
        self.slot(page_number).fetch_add(1, Ordering::Release);
    }

    /// Page `page_number` lost its last version.
    fn removed(&self, page_number: u64) {
        self.slot(page_number).fetch_sub(1, Ordering::Release);
    }

    /// Whether page `page_number` may have a version here.
    fn may_have(&self, page_number: u64) -> bool {
        self.slot(page_number).load(Ordering::Acquire) != 0
    }
}

struct State {
    /// Number of the newest committed version: commits are numbered on from what the header records (J6).
    last_committed: u64,
    /// Versions of each page that are only here, oldest first.
    versions: HashMap<u64, Vec<Version>>,
    /// Which pages may have versions, for the snapshots that read without the lock; the same as `Shared::filter`.
    filter: Arc<VersionFilter>,
    /// For each page whose older versions left `versions` without being written in place, because no snapshot
    /// needed them any more, the commit of the oldest of them: `krummi.data` still holds what the page was before it,
    /// so the journal records from that commit on are needed until the page is written. The journal keeps only the
    /// bytes each commit changed, which recovery applies over `krummi.data` (Y2 of the journal page diffs PRD).
    unwritten: HashMap<u64, u64>,
    /// Bytes taken by `versions` and `retired` (T14): a page of its own for each version of one in `versions`, and the
    /// whole slots of a value run while one of its pages keeps a version in either, even when newer versions replaced
    /// the others (see [`State::hold`]).
    bytes: u64,
    /// Versions in `versions` and in `retired` of each value run, by the address of its slots.
    run_holders: HashMap<usize, usize>,
    /// Open read snapshots by ascending sequence number; their versions never decrease along the list.
    live: Vec<Live>,
    /// The writer's snapshot, which sees commits that are not durable yet (E3).
    writer: Option<Live>,
    next_seq: u64,
    /// Versions that left `versions`, with the newest sequence number issued when they left: they are freed
    /// once no open snapshot has a sequence number up to that one, or no read snapshot at the writer's own flush.
    retired: Vec<(u64, Arc<Slot>)>,
}

struct Version {
    txid: u64,
    /// The slots holding the page: its own, or those of its value run.
    page: Arc<Slot>,
    /// Index of the page in `page`: 0 for a page of its own.
    index: usize,
}

#[derive(Clone, Copy)]
struct Live {
    seq: u64,
    txid: u64,
}

impl Scratch {
    /// Recovers the store if it closed in a crash (J8 of the Journal PRD) and puts a scratch area and an empty
    /// journal in front of it, with the transfer thread (J5). Recovery removes the journal and the temporary area
    /// a crash left.
    pub fn open(mut pager: Pager) -> Result<Scratch> {
        let signal = Arc::new(Signal::new());
        let (journal, (transfers, sender)) = match pager.folder().map(Path::to_path_buf) {
            Some(folder) => {
                // Both threads start first: failing to start one leaves the store untouched (E13).
                let journal = Journal::start(&folder, &pager)?;
                let thread = transfer::start(&signal)?;
                let recovered = recovery::recover(&mut pager, &folder)?;
                journal.begin(recovered.last_txid, recovered.next_number);
                let durable = Arc::clone(&signal);
                journal.set_durable_hook(Some(Arc::new(move || durable.raise(0))));
                (Some(journal), thread)
            }
            None => (None, transfer::start(&signal)?),
        };
        let scratch = Scratch::with_journal(pager, journal, signal, Some(transfers));
        // The thread ends at once if this fails, and the store is closed without it.
        let _ = sender.send(Arc::clone(&scratch.shared));
        Ok(scratch)
    }

    /// Puts a scratch area in front of a store, with no journal and no transfer thread (tests of the scratch
    /// area).
    pub fn new(pager: Pager) -> Scratch {
        Scratch::with_journal(pager, None, Arc::new(Signal::new()), None)
    }

    fn with_journal(
        pager: Pager,
        journal: Option<Journal>,
        signal: Arc<Signal>,
        transfers: Option<JoinHandle<()>>,
    ) -> Scratch {
        let header = pager.header();
        let filter = Arc::new(VersionFilter::new());
        let shared = Shared {
            area: Arc::new(TempArea::new(pager.folder(), pager.info().max_size)),
            journal,
            pager: Some(pager),
            flushing: Mutex::new(()),
            signal,
            transfer_hook: Mutex::new(None),
            failure_hook: Mutex::new(None),
            passes: AtomicU64::new(0),
            #[cfg(any(test, feature = "test-hooks"))]
            version_checks: AtomicU64::new(0),
            filter: Arc::clone(&filter),
            state: RwLock::new(State {
                last_committed: header.applied_txid,
                versions: HashMap::new(),
                filter,
                unwritten: HashMap::new(),
                bytes: 0,
                run_holders: HashMap::new(),
                live: Vec::new(),
                writer: None,
                next_seq: 0,
                retired: Vec::new(),
            }),
        };
        Scratch {
            shared: Arc::new(shared),
            writer: Mutex::new(()),
            transfers,
        }
    }

    /// The store under the scratch area.
    pub fn pager(&self) -> &Pager {
        self.shared.pager()
    }

    /// Flips every bit of byte `offset` of the payload of page `page_number` where the store keeps it, without
    /// changing its checksum: damage that appears while the store is open (tests of the remembered node layout check
    /// PRD, AC-C7). The page must be intact and have no version in this area.
    ///
    /// # Panics
    ///
    /// If the page is a header page or beyond the store, has a version in this area, or `offset` is beyond the
    /// payload.
    #[cfg(feature = "test-hooks")]
    pub fn flip_byte_in_place(&mut self, page_number: u64, offset: usize) -> Result<()> {
        assert!(
            offset < PAGE_SIZE - PAGE_HEADER_SIZE,
            "offset {offset} is beyond the payload"
        );
        assert!(
            !self.lock().versions.contains_key(&page_number),
            "page {page_number} has a version in the scratch area, which reads see instead"
        );
        let _flushing = self
            .shared
            .flushing
            .lock()
            .unwrap_or_else(PoisonError::into_inner);
        let pager = self.shared.pager();
        let mut page = pager.run(page_number, 1)?.to_vec();
        page[PAGE_HEADER_SIZE + offset] ^= 0xFF;
        // SAFETY: borrowing this area mutably means no snapshot of it is alive, and every reference into the store's
        // pages borrows a snapshot or this area, so none is alive; holding `flushing` keeps the transfer thread from
        // writing pages in place meanwhile, the only other writer while the store is open. The page stays
        // remembered: the flip stands for a change the engine does not make (I8).
        unsafe { pager.write_unremembered(page_number, &page) }
    }

    /// Information about the store (P12).
    pub fn info(&self) -> Info {
        self.pager().info()
    }

    /// Bytes of page versions held only in the scratch area (T14).
    pub fn scratch_bytes(&self) -> u64 {
        self.lock().bytes
    }

    /// Bytes the temporary area holds, free slots included: the files of `krummi.temp`, or the memory of a temporary
    /// store's versions (tests).
    pub fn area_bytes(&self) -> u64 {
        self.shared.area.capacity()
    }

    /// Where `bytes` live, if in the store's pages or in the temporary area (tests: AC20, AC-V3).
    pub fn memory_of(&self, bytes: &[u8]) -> Option<Memory> {
        if self.pager().holds(bytes) {
            Some(Memory::Data)
        } else if self.shared.area.holds(bytes) {
            Some(Memory::Versions)
        } else {
            None
        }
    }

    /// Opens a snapshot of everything committed and durable so far (T2, G3, E3).
    pub fn snapshot(&self) -> Result<Snapshot<'_>> {
        let mut state = self.lock();
        self.register(&mut state, false)
    }

    /// Waits until no other writer exists and returns the writer, with a snapshot of everything committed so far,
    /// durable or not (E3).
    pub fn begin_write(&self) -> Result<ScratchWriter<'_>> {
        let guard = self.writer.lock().unwrap_or_else(PoisonError::into_inner);
        let snapshot = {
            let mut state = self.lock();
            self.register(&mut state, true)?
        };
        Ok(ScratchWriter {
            snapshot,
            _guard: guard,
            _not_shared: PhantomData,
        })
    }

    /// Waits until every commit that passed its point of no return is durable (J11, E10). Fails at once with the I/O
    /// class when the store refuses writes (T12). A temporary store has nothing to do (J17).
    pub fn make_durable(&self) -> Result<()> {
        let pager = self.pager();
        pager.check_writable()?;
        match &self.shared.journal {
            Some(journal) => journal.make_durable(pager),
            None => Ok(()),
        }
    }

    /// Waits until commit `txid` is durable, or fails with the I/O class if its group failed (J4, E8). A temporary
    /// store has nothing to wait for.
    pub fn wait_durable(&self, txid: u64) -> Result<()> {
        match &self.shared.journal {
            Some(journal) => journal.wait_durable(txid),
            None => Ok(()),
        }
    }

    /// Wakes the commits waiting for room in the journal's queue, after the store stopped accepting writes (T12).
    pub fn wake(&self) {
        self.shared.wake();
    }

    /// Sets the function called when the journal's writer fails a group or the transfer thread fails a transfer,
    /// or none (T12, J13).
    pub fn set_failure_hook(&self, hook: Option<Arc<dyn Fn() + Send + Sync>>) {
        if let Some(journal) = &self.shared.journal {
            journal.set_failure_hook(hook.clone());
        }
        *self
            .shared
            .failure_hook
            .lock()
            .unwrap_or_else(PoisonError::into_inner) = hook;
    }

    /// Stops the journal's writer from taking queued commits, or lets it go on (tests).
    pub fn set_journal_paused(&self, paused: bool) {
        if let Some(journal) = &self.shared.journal {
            journal.set_paused(paused);
        }
    }

    /// Number of commits waiting in the journal's queue (tests).
    pub fn journal_queued(&self) -> usize {
        self.shared.journal.as_ref().map_or(0, Journal::queued)
    }

    /// Writes of groups so far, one per journal file a group touches (tests).
    pub fn journal_writes(&self) -> u64 {
        self.shared.journal.as_ref().map_or(0, Journal::writes)
    }

    /// Last durable commit (tests).
    pub fn journal_durable(&self) -> u64 {
        self.shared
            .journal
            .as_ref()
            .map_or(self.lock().last_committed, Journal::durable)
    }

    /// Sets the bytes the journal's queue holds before a commit waits for room (tests).
    pub fn set_journal_queue_limit(&self, bytes: u64) {
        if let Some(journal) = &self.shared.journal {
            journal.set_queue_limit(bytes);
        }
    }

    /// Has the transfer thread run a pass now and waits for it; the pass releases the journal files it can however
    /// recently `krummi.data` was flushed (tests: AC-E17).
    pub fn transfer(&self) -> Result<()> {
        self.demand(Demand::Pass)
    }

    /// Layout checks of versions of the scratch area that the layers above reported so far, passed or failed (tests
    /// of the version checks PRD).
    #[cfg(any(test, feature = "test-hooks"))]
    pub fn version_checks(&self) -> u64 {
        self.shared.version_checks.load(Ordering::Relaxed)
    }

    /// Transfer passes so far, by the transfer thread or [`Scratch::transfer`] (tests).
    pub fn transfer_passes(&self) -> u64 {
        self.shared.passes.load(Ordering::Relaxed)
    }

    /// Sets the minimum time between passes and the growth of the scratch area since the last pass from which a
    /// pass starts without waiting for it (tests).
    pub fn set_transfer_pacing(&self, interval: Duration, bytes: u64) {
        self.shared.signal.set_pacing(Pacing { interval, bytes });
    }

    /// Stops the transfer thread from starting passes, waiting for the one it may be running, or lets it go on
    /// (tests that need every transfer to run on their own thread).
    pub fn set_transfer_paused(&self, paused: bool) {
        self.shared.signal.set_paused(paused);
        if paused {
            drop(
                self.shared
                    .flushing
                    .lock()
                    .unwrap_or_else(PoisonError::into_inner),
            );
        }
    }

    /// A flag that stays set while the transfer thread runs (tests).
    pub fn transfer_thread_alive(&self) -> Arc<AtomicBool> {
        self.shared.signal.alive()
    }

    /// Sets a function a transfer calls while it holds its lock, after it chose the versions it writes and before
    /// it writes them, or none (tests: AC-J17).
    pub fn set_transfer_hook(&self, hook: Option<Arc<dyn Fn() + Send + Sync>>) {
        *self
            .shared
            .transfer_hook
            .lock()
            .unwrap_or_else(PoisonError::into_inner) = hook;
    }

    /// Sets the function the journal's writer calls between writing a group and making it durable (tests).
    pub fn set_journal_sync_hook(&self, hook: Option<Arc<dyn Fn() + Send + Sync>>) {
        if let Some(journal) = &self.shared.journal {
            journal.set_sync_hook(hook);
        }
    }

    /// Sets the size at which the journal goes on in a new file (tests).
    pub fn set_journal_file_limit(&self, bytes: u64) {
        if let Some(journal) = &self.shared.journal {
            journal.set_file_limit(bytes);
        }
    }

    /// Has the transfer thread transfer everything no read needs and record it in both header copies, so that the
    /// journal keeps only what later commits need, and waits for it (tests: AC-J18).
    pub fn checkpoint(&self) -> Result<()> {
        self.demand(Demand::Checkpoint)
    }

    /// Has the transfer thread do `demand` and waits for it, so that no other thread transfers (J5); a store
    /// without the thread does it here.
    fn demand(&self, demand: Demand) -> Result<()> {
        match self.shared.signal.demand(demand) {
            Some(outcome) => outcome,
            None => self.shared.serve(demand),
        }
    }

    /// Writes every committed version to the data file and closes the store, which releases its lock even if a
    /// write fails (P14). A store that refused writes after a failure tries them again here (T12); if the close
    /// fails, the journal stays for the next opening to recover (J14).
    pub fn close(mut self) -> Result<()> {
        self.stop_transfers();
        let shared = Arc::get_mut(&mut self.shared).expect("the transfer thread ended");
        let flushed = shared.flush_all();
        let pager = shared.pager.take().expect("the store is open");
        let closed = pager.close();
        flushed.and(closed)
    }

    /// Ends the transfer thread, after the pass it may be running.
    fn stop_transfers(&mut self) {
        self.shared.signal.stop();
        if let Some(handle) = self.transfers.take() {
            // A thread that panicked left nothing half done that the close cannot redo.
            let _ = handle.join();
        }
    }

    fn lock(&self) -> RwLockWriteGuard<'_, State> {
        self.shared.lock()
    }

    /// The state, shared with other reads of it (U3 of the version checks PRD).
    fn read(&self) -> RwLockReadGuard<'_, State> {
        self.shared.read()
    }

    /// The newest commit a read transaction opened now would see: the last durable one, or in a temporary store,
    /// which has no journal, the last one published (E3, E14). It registers nothing, so it never fails.
    pub fn visible_txid(&self) -> u64 {
        self.visible(&self.lock())
    }

    fn visible(&self, state: &State) -> u64 {
        match &self.shared.journal {
            Some(journal) => state.last_committed.min(journal.durable()),
            None => state.last_committed,
        }
    }

    /// Registers a read snapshot of what is durable, or the writer's snapshot of everything published (E3).
    fn register(&self, state: &mut State, writer: bool) -> Result<Snapshot<'_>> {
        let out_of_memory = || Error::OutOfMemory {
            requested: size_of::<Live>() as u64,
        };
        sys::snapshot_point().map_err(|_| out_of_memory())?;
        let txid = if writer {
            state.last_committed
        } else {
            self.visible(state)
        };
        let live = Live {
            seq: state.next_seq,
            txid,
        };
        if writer {
            state.writer = Some(live);
        } else {
            state.live.try_reserve(1).map_err(|_| out_of_memory())?;
            state.live.push(live);
        }
        state.next_seq += 1;
        Ok(Snapshot {
            scratch: self,
            seq: live.seq,
            txid: live.txid,
            writer,
            may_see_versions: !state.versions.is_empty(),
        })
    }
}

impl Drop for Scratch {
    /// A store dropped without closing still writes what was committed, without reporting a failure (T9).
    fn drop(&mut self) {
        self.stop_transfers();
        if let Some(shared) = Arc::get_mut(&mut self.shared)
            && shared.pager.is_some()
        {
            let _ = shared.flush_all();
        }
    }
}

impl Shared {
    fn pager(&self) -> &Pager {
        self.pager.as_ref().expect("the store is open")
    }

    fn lock(&self) -> RwLockWriteGuard<'_, State> {
        self.state.write().unwrap_or_else(PoisonError::into_inner)
    }

    fn read(&self) -> RwLockReadGuard<'_, State> {
        self.state.read().unwrap_or_else(PoisonError::into_inner)
    }

    /// Bytes of page versions held only in the scratch area (T14).
    pub(crate) fn scratch_bytes(&self) -> u64 {
        self.lock().bytes
    }

    fn wake(&self) {
        if let Some(journal) = &self.journal {
            journal.wake();
        }
    }

    /// One transfer pass (J5): writes in place the durable versions no read needs any more, then releases the
    /// journal files `krummi.data` no longer needs.
    pub(crate) fn pass(&self) -> Result<()> {
        let flushing = self.flushing.lock().unwrap_or_else(PoisonError::into_inner);
        self.passes.fetch_add(1, Ordering::Relaxed);
        self.flush_locked(&flushing, false)?;
        self.release_files(&flushing)
    }

    /// Does what a caller asked the transfer thread for.
    pub(crate) fn serve(&self, demand: Demand) -> Result<()> {
        if let Demand::Pass = demand {
            return self.pass();
        }
        let flushing = self.flushing.lock().unwrap_or_else(PoisonError::into_inner);
        self.flush_locked(&flushing, true)?;
        if let Demand::Flush = demand {
            return self.release_files(&flushing);
        }
        if let Some(journal) = &self.journal {
            journal.start_new_file(self.pager())?;
        }
        self.record_applied(&flushing)
    }

    /// Whether the store refuses writes after a failed write (T12).
    pub(crate) fn refuses_writes(&self) -> bool {
        !self.pager().accepts_writes()
    }

    /// Lets the transaction layer know that a transfer failed outside any operation and made the store refuse
    /// writes (J13): the waiting requests and the commits waiting for room in the journal's queue fail at once
    /// (T12). A failure that leaves the store accepting writes reports nothing.
    pub(crate) fn report_failure(&self) {
        if !self.refuses_writes() {
            return;
        }
        let hook = self
            .failure_hook
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .clone();
        if let Some(hook) = hook {
            hook();
        }
        self.wake();
    }

    /// Writes in place every newest version that no open snapshot is older than and that is durable, after
    /// retiring the versions that no snapshot can read any more; with `force`, it first waits until every queued
    /// commit is durable, so every such version goes (J5). It calls the test hook once it knows what it writes.
    fn flush_locked(&self, _flushing: &MutexGuard<'_, ()>, force: bool) -> Result<()> {
        let pager = self.pager();
        if force && let Some(journal) = &self.journal {
            journal.make_durable(pager)?;
        }
        let durable = self.journal.as_ref().map_or(u64::MAX, Journal::durable);
        let garbage;
        // The commit, first page and slots of each page or value run to write (see the module documentation).
        let mut pending: Vec<(u64, u64, Arc<Slot>)> = {
            let mut state = self.lock();
            let visible = state.last_committed.min(durable);
            garbage = state.collect_garbage(visible);
            let oldest = state.live.first().map(|l| l.txid);
            state
                .versions
                .iter()
                .filter_map(|(&page_number, versions)| {
                    let newest = versions.last()?;
                    let first = page_number - newest.index as u64;
                    (newest.txid <= durable && oldest.is_none_or(|oldest| oldest >= newest.txid))
                        .then(|| (newest.txid, first, Arc::clone(&newest.page)))
                })
                .collect()
        };
        drop(garbage);
        // In the order of the commits, and of the pages within each; a run comes once.
        pending.sort_unstable_by_key(|(txid, first, _)| (*txid, *first));
        pending.dedup_by_key(|(txid, first, _)| (*txid, *first));
        let hook = self
            .transfer_hook
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .clone();
        if let Some(hook) = hook {
            hook();
        }
        let mut written = 0;
        let mut outcome = Ok(());
        for (_, first, slots) in &pending {
            // SAFETY: see the module documentation: every open snapshot reads these pages from the scratch area,
            // where their versions stay until the write ends, and `flushing` makes this the only write.
            if let Err(error) = unsafe { pager.write_run_shared(*first, slots.bytes()) } {
                outcome = Err(error);
                break;
            }
            written += 1;
        }
        // The versions written, those before a failure too, leave the scratch area under one lock; those no open
        // snapshot can hold a reference to are freed at once, so the temporary area does not keep them until the
        // next snapshot ends.
        let mut state = self.lock();
        for (txid, first, slots) in &pending[..written] {
            for page_number in *first..*first + slots.pages() as u64 {
                state.written(page_number, *txid, slots.pages() > 1);
            }
        }
        let free = state.free_retired();
        drop(state);
        drop(pending);
        drop(free);
        outcome
    }

    /// Releases the journal files that `krummi.data` no longer needs (J6), only when the oldest one can go: otherwise
    /// flushing `krummi.data` frees nothing.
    fn release_files(&self, flushing: &MutexGuard<'_, ()>) -> Result<()> {
        match &self.journal {
            Some(journal) if journal.can_remove_files(self.applied(journal)) => {
                self.record_applied(flushing)
            }
            _ => Ok(()),
        }
    }

    /// Flushes `krummi.data`, records in both header copies the last commit it holds entirely, and removes the
    /// journal files neither copy needs any more (J6).
    fn record_applied(&self, _flushing: &MutexGuard<'_, ()>) -> Result<()> {
        let Some(journal) = &self.journal else {
            return Ok(());
        };
        let pager = self.pager();
        pager.flush_data()?;
        let applied = self.applied(journal);
        // A file goes only once both copies record it, so both are written now (J8).
        for _ in 0..2 {
            pager.write_header(Header {
                applied_txid: applied,
                journal_first: journal.first_needed(applied),
                ..pager.header()
            })?;
        }
        journal.remove_files(pager, pager.applied_by_both_copies(), false)
    }

    /// The last commit `krummi.data` holds entirely once the versions written in place are flushed. Versions newer
    /// than the last durable commit are never written in place, and the ones they supersede are kept, so it never
    /// goes past it (J4, E3).
    fn applied(&self, journal: &Journal) -> u64 {
        self.lock().applied().min(journal.durable())
    }

    /// Makes the journal durable, writes the newest version of every page to the data file, records it in both
    /// header copies and removes the journal and the temporary area (J14).
    fn flush_all(&mut self) -> Result<()> {
        let pager = self.pager.as_mut().expect("the store is open");
        pager.allow_writes_again();
        if let Some(journal) = &self.journal {
            // Writes what is queued, retrying a group that failed, and stops the journal's writer (E12).
            journal.close(pager)?;
        }
        let state = self.state.get_mut().unwrap_or_else(PoisonError::into_inner);
        let mut pages: Vec<_> = state.versions.keys().copied().collect();
        pages.sort_unstable();
        let pages_written = pages.len();
        for page_number in pages {
            let version = state.versions[&page_number]
                .last()
                .expect("a page in the scratch area has a version");
            let page = version.page.page_at(version.index);
            // SAFETY: `&mut self` rules out open snapshots, and with them any reference into the store's pages
            // and any other write.
            unsafe { pager.write_run_shared(page_number, page)? };
            let versions = state.versions.remove(&page_number).unwrap_or_default();
            if !versions.is_empty() {
                state.filter.removed(page_number);
            }
            for version in versions {
                state.release(&version.page);
            }
        }
        // No snapshot is open, so every retired version is freed.
        drop(state.free_retired());
        debug_assert_eq!(state.bytes, 0, "every version left the scratch area");
        // Nothing was committed since the store opened: `krummi.data` and its header are already what a close
        // would leave, so a close writes nothing, unless a header copy is damaged and the close can repair it (P6).
        let unchanged = pages_written == 0
            && self.journal.as_ref().is_none_or(Journal::has_no_files)
            && !pager.has_damaged_header_copy();
        if let Some(journal) = self.journal.as_ref().filter(|_| !unchanged) {
            pager.flush_data()?;
            let applied = state.last_committed;
            for _ in 0..2 {
                pager.write_header(Header {
                    applied_txid: applied,
                    journal_first: journal.first_needed(applied),
                    ..pager.header()
                })?;
            }
            journal.remove_files(pager, applied, true)?;
        }
        self.area.remove().map_err(|e| pager.fail_write(e, 0))
    }
}

impl State {
    /// The last commit whose changes are all in the data file: every version left here is newer.
    fn applied(&self) -> u64 {
        self.versions
            .values()
            .filter_map(|versions| versions.first())
            .map(|v| v.txid)
            .chain(self.unwritten.values().copied())
            .min()
            .map_or(self.last_committed, |txid| txid - 1)
    }

    /// Whether the filter counts exactly the pages with versions in each of its slots (tests).
    #[cfg(test)]
    fn filter_agrees(&self) -> bool {
        let mut counts = HashMap::<u64, u32>::new();
        for (&page_number, versions) in &self.versions {
            assert!(
                !versions.is_empty(),
                "page {page_number} keeps an empty list"
            );
            *counts.entry(page_number % FILTER_SLOTS).or_default() += 1;
        }
        (0..FILTER_SLOTS).all(|slot| {
            self.filter.0[slot as usize].load(Ordering::Relaxed)
                == counts.get(&slot).copied().unwrap_or(0)
        })
    }

    /// Takes the versions of `page_number` out once its version of commit `txid` was written in place: all of them
    /// when it is still the newest, and none when a newer commit published another one meanwhile; for a page of a
    /// value run (`run`), that version and the ones before it even then, so that no snapshot finds part of the run
    /// here and the rest in the data file (see the module documentation).
    fn written(&mut self, page_number: u64, txid: u64, run: bool) {
        let Some(versions) = self.versions.get_mut(&page_number) else {
            return;
        };
        let Some(at) = versions.iter().position(|v| v.txid == txid) else {
            return;
        };
        let gone: Vec<Version> = if at + 1 == versions.len() {
            self.filter.removed(page_number);
            self.versions.remove(&page_number).unwrap_or_default()
        } else if run {
            versions.drain(..=at).collect()
        } else {
            return;
        };
        // `krummi.data` holds this version now, newer than any dropped unwritten.
        self.unwritten.remove(&page_number);
        self.retire(gone);
    }

    /// Counts in `bytes` a version, held in `page`, that goes into `versions` (T14, P10): a page of its own takes its
    /// page; the first version of a value run takes the run's whole slots, which stay counted until its last version
    /// is freed, from `versions` or from `retired` ([`State::release`]). A run's slots are one allocation of the
    /// temporary area, kept whole while any of its versions is, so a run whose other pages got newer versions, or
    /// were written in place and retired, still counts whole: the maximum-size accounting covers every slot the
    /// versions keep (R1 of the large values code review).
    fn hold(&mut self, page: &Arc<Slot>) {
        let pages = page.pages();
        if pages == 1 {
            self.bytes += PAGE_SIZE_U64;
            return;
        }
        let holders = self
            .run_holders
            .entry(Arc::as_ptr(page).addr())
            .or_insert(0);
        if *holders == 0 {
            self.bytes += pages as u64 * PAGE_SIZE_U64;
        }
        *holders += 1;
    }

    /// Stops counting a version, held in `page`, that leaves the accounting: a page of its own when it leaves
    /// `versions`, and a run's version when it is freed; the run's whole slots stop counting with its last version
    /// ([`State::hold`]).
    fn release(&mut self, page: &Arc<Slot>) {
        let pages = page.pages();
        if pages == 1 {
            self.bytes -= PAGE_SIZE_U64;
            return;
        }
        let key = Arc::as_ptr(page).addr();
        let holders = self
            .run_holders
            .get_mut(&key)
            .expect("a run's version in the scratch area or retired is counted");
        *holders -= 1;
        if *holders == 0 {
            self.run_holders.remove(&key);
            self.bytes -= pages as u64 * PAGE_SIZE_U64;
        }
    }

    /// Moves page versions out of `versions`; they are freed once the snapshots that may use them end. A page of its
    /// own stops counting now, and a run's version when it is freed ([`State::free_retired`]), so that the run's
    /// slots count while they stay allocated (see the module documentation).
    fn retire(&mut self, versions: impl IntoIterator<Item = Version>) {
        let bound = self.next_seq.saturating_sub(1);
        for version in versions {
            if !counted_while_retired(&version.page) {
                self.release(&version.page);
            }
            self.retired.push((bound, version.page));
        }
    }

    /// Takes out the versions that no snapshot can read any more, for the caller to free. A version that has a
    /// newer one is read only by the snapshots at least as new as it and older than the newer one; with none
    /// open, nobody needs it, and nobody can hold a reference to it either: a snapshot that read it would be one
    /// of those. So it is freed at once, not retired, and a long snapshot does not make them pile up (T14). A
    /// version whose newer one is beyond `visible`, the newest commit read snapshots see, is kept for the read
    /// snapshots still to open (E3).
    fn collect_garbage(&mut self, visible: u64) -> Vec<Version> {
        let mut dropped = Vec::new();
        for (&page_number, versions) in &mut self.versions {
            if versions.len() < 2 {
                continue;
            }
            let before = dropped.len();
            let mut kept = Vec::with_capacity(versions.len());
            let mut iter = std::mem::take(versions).into_iter().peekable();
            while let Some(version) = iter.next() {
                let needed = match iter.peek() {
                    None => true,
                    Some(next) if next.txid > visible => true,
                    Some(next) => {
                        let first = self.live.partition_point(|l| l.txid < version.txid);
                        self.live.get(first).is_some_and(|l| l.txid < next.txid)
                    }
                };
                if needed {
                    kept.push(version);
                } else {
                    dropped.push(version);
                }
            }
            *versions = kept;
            if let Some(oldest) = dropped.get(before) {
                let since = oldest.txid;
                self.unwritten
                    .entry(page_number)
                    .and_modify(|first| *first = (*first).min(since))
                    .or_insert(since);
            }
        }
        for version in &dropped {
            self.release(&version.page);
        }
        dropped
    }

    /// Frees the retired versions that no open snapshot, the writer's included, can hold a reference to.
    fn free_retired(&mut self) -> Vec<Arc<Slot>> {
        let writer = self.writer.map_or(u64::MAX, |w| w.seq);
        self.free_retired_before(self.oldest_read().min(writer))
    }

    /// Frees, for the writer's own flush ([`ScratchWriter::flush`]), the retired versions that no open read
    /// snapshot can hold a reference to, whatever the writer's snapshot read: the writer's snapshot returns
    /// references that borrow the writer, and the flush borrows it mutably, so none of them is alive (T8 of the
    /// Transactions PRD). Otherwise a run that the write's own flush retires would stay allocated and counted until
    /// the write ends, and the write could fail with the maximum-size class because of versions no read needs (J7
    /// of the Journal PRD; R2 of the fourth large values code follow-up review).
    fn free_retired_by_writer(&mut self) -> Vec<Arc<Slot>> {
        self.free_retired_before(self.oldest_read())
    }

    /// The sequence number of the oldest open read snapshot, or `u64::MAX` with none.
    fn oldest_read(&self) -> u64 {
        self.live.first().map_or(u64::MAX, |l| l.seq)
    }

    /// Frees the retired versions whose bound is below `oldest`, releasing a run's share of the charge.
    fn free_retired_before(&mut self, oldest: u64) -> Vec<Arc<Slot>> {
        let (free, keep): (Vec<_>, Vec<_>) = std::mem::take(&mut self.retired)
            .into_iter()
            .partition(|(bound, _)| *bound < oldest);
        self.retired = keep;
        free.into_iter()
            .map(|(_, page)| {
                if counted_while_retired(&page) {
                    self.release(&page);
                }
                page
            })
            .collect()
    }
}

/// Whether a retired version, held in `page`, still counts for the maximum size: a run's version does, since its
/// slots may hold more than the data file does (see the module documentation); a page of its own does not.
fn counted_while_retired(page: &Slot) -> bool {
    page.pages() > 1
}

/// Where a page that a snapshot reads comes from, for the layout check of the layers above.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Origin {
    /// The store's pages, with the integrity code stored in the page as read, which this read verified or a read of
    /// this opening already did (C2 of the remembered node layout check PRD, I2).
    Store(u64),
    /// A committed version in the scratch area, which no read verifies (I3), and whether its layout already passed
    /// the check of the layers above (U1 of the version checks PRD).
    Version {
        /// The version passed the layout check since it was published.
        checked: bool,
    },
}

/// A view of the store as it was when the snapshot opened (G3). It can be sent to and shared between threads
/// (T6), and the references it returns live as long as it does (D11).
pub struct Snapshot<'a> {
    scratch: &'a Scratch,
    seq: u64,
    txid: u64,
    /// Whether it is the writer's snapshot (E3).
    writer: bool,
    /// Whether the scratch area held any version when this snapshot opened. A version published later is newer than
    /// the snapshot, so it never applies to it: without one at the start, its reads skip the scratch lock (O2 of the
    /// performance plan).
    may_see_versions: bool,
}

impl<'a> Snapshot<'a> {
    /// Number of the newest committed version this snapshot sees.
    pub fn txid(&self) -> u64 {
        self.txid
    }

    /// The store this snapshot reads.
    pub fn scratch(&self) -> &'a Scratch {
        self.scratch
    }

    /// The payload of page `page_number` as this snapshot sees it, without copying it (D11, T16): the newest
    /// version not newer than the snapshot from the scratch area, or else the page in the store.
    ///
    /// # Panics
    ///
    /// If `page_number` is a header page.
    pub fn page(&self, page_number: u64) -> Result<&[u8]> {
        self.page_and_code(page_number).map(|(page, _)| page)
    }

    /// The payload of page `page_number`, as [`page`](Self::page), with where it comes from: the store, with the
    /// integrity code its read verified (C2 of the remembered node layout check PRD), or a version of the scratch
    /// area, with whether its layout already passed the check (U1 of the version checks PRD).
    ///
    /// # Panics
    ///
    /// If `page_number` is a header page.
    pub fn page_and_code(&self, page_number: u64) -> Result<(&[u8], Origin)> {
        let state = (self.may_see_versions && self.scratch.shared.filter.may_have(page_number))
            .then(|| self.scratch.read());
        let version = state
            .as_ref()
            .and_then(|state| state.versions.get(&page_number))
            .and_then(|versions| versions.iter().rev().find(|v| v.txid <= self.txid));
        if let Some(version) = version {
            if version.page.pages() > 1 {
                // A page of a value run is no page of its own, as in the store (D1).
                drop(state);
                return Err(self.scratch.pager().damaged(page_number));
            }
            let ptr = version.page.page().as_ptr();
            let checked = version.page.layout_checked();
            drop(state);
            // SAFETY: `ptr` points to the PAGE_SIZE bytes of a slot of the temporary area owned by an `Arc` in the
            // scratch area; the area keeps a slot's memory while the slot is held.
            // The scratch area keeps that `Arc` while this snapshot is open: a version leaves `versions` only by
            // being retired with a bound at least this snapshot's sequence number, and retired versions are freed
            // only once no open snapshot has a sequence number up to their bound, but for the writer's snapshot,
            // whose retired versions its own flush frees: the flush borrows the writer mutably, which ends this
            // reference first ([`State::free_retired_by_writer`]). Published pages are never written again.
            let page = unsafe { std::slice::from_raw_parts(ptr, PAGE_SIZE) };
            return Ok((&page[PAGE_HEADER_SIZE..], Origin::Version { checked }));
        }
        drop(state);
        // No version up to this snapshot is in the scratch area: the store has the one it sees, and no flush
        // writes this page while the snapshot is open, because any newer version is newer than the snapshot. Read and
        // write transactions alike use the remembered pages (I2 of the remembered page integrity PRD, S2 of the
        // writer checks PRD).
        let (page, code) = self
            .scratch
            .pager()
            .page_and_code_with(page_number, Integrity::UseRemembered)?;
        Ok((page, Origin::Store(code)))
    }

    /// Asks the processor to bring page `page_number` into its caches when this snapshot sees it in the store, so that
    /// a read soon after finds it there ([`Pager::prefetch`]). A page that may have a version in the scratch area is
    /// left alone: telling which version this snapshot sees takes the lock, which costs more than the wait it saves.
    pub fn prefetch(&self, page_number: u64) {
        if !(self.may_see_versions && self.scratch.shared.filter.may_have(page_number)) {
            self.scratch.pager().prefetch(page_number);
        }
    }

    /// Reports that the layers above checked the layout of `node`, the payload of page `page_number` read as a
    /// version of the scratch area, and whether it `passed`. A pass is remembered by that version, for every later
    /// read of it while it stays in the scratch area, by any snapshot; a failure is never remembered (U1 of the
    /// version checks PRD). Only the version whose payload is `node` is marked.
    pub fn version_checked(&self, page_number: u64, node: &[u8], passed: bool) {
        #[cfg(any(test, feature = "test-hooks"))]
        self.scratch
            .shared
            .version_checks
            .fetch_add(1, Ordering::Relaxed);
        if !passed || !self.may_see_versions {
            return;
        }
        let state = self.scratch.read();
        if let Some(version) = state
            .versions
            .get(&page_number)
            .and_then(|versions| versions.iter().rev().find(|v| v.txid <= self.txid))
            && version.page.page()[PAGE_HEADER_SIZE..].as_ptr() == node.as_ptr()
        {
            version.page.remember_layout_checked();
        }
    }

    /// The `count` pages of the value run that starts at page `first` as this snapshot sees it, as one contiguous
    /// sequence without copying it (V2 of the large values PRD, D5 of its execution): the run's slots in the
    /// temporary area when this snapshot sees its version there, or else the run in the store, checked (D3). The
    /// reference lives as long as the snapshot (D11). When what this snapshot sees in those pages is not one run of
    /// exactly `count` pages, all here or all in the store, it is the damage class with page `first` (V7).
    ///
    /// # Panics
    ///
    /// If `first` is a header page.
    pub fn run(&self, first: u64, count: u64) -> Result<&[u8]> {
        assert!(
            first >= HEADER_PAGES,
            "header pages are not read through Snapshot::run"
        );
        let pager = self.scratch.pager();
        let end = first
            .checked_add(count)
            .filter(|&end| count > 0 && end <= pager.page_count());
        let Some(end) = end else {
            return Err(pager.damaged(first));
        };
        let filter = &self.scratch.shared.filter;
        let state = (self.may_see_versions
            && (first..end).any(|page_number| filter.may_have(page_number)))
        .then(|| self.scratch.read());
        let seen = |page_number: u64| {
            state
                .as_ref()?
                .versions
                .get(&page_number)
                .and_then(|versions| versions.iter().rev().find(|v| v.txid <= self.txid))
        };
        let head = seen(first);
        let whole = match head {
            None => (first + 1..end).all(|page_number| seen(page_number).is_none()),
            Some(head) => {
                head.index == 0
                    && head.page.pages() as u64 == count
                    && (first + 1..end).zip(1..).all(|(page_number, index)| {
                        seen(page_number)
                            .is_some_and(|v| v.index == index && Arc::ptr_eq(&v.page, &head.page))
                    })
            }
        };
        let bytes = head.map(|head| {
            let bytes = head.page.bytes();
            (bytes.as_ptr(), bytes.len())
        });
        drop(state);
        match bytes {
            _ if !whole => Err(pager.damaged(first)),
            // SAFETY: as in `Snapshot::page`: `ptr` points to the `len` bytes of the run's slots, owned by `Arc`s
            // that the scratch area keeps while this snapshot is open, and never written again.
            Some((ptr, len)) => Ok(unsafe { std::slice::from_raw_parts(ptr, len) }),
            // None of these pages has a version up to this snapshot in the scratch area: as in `Snapshot::page`, the
            // store has what it sees, and no flush writes these pages while the snapshot is open. A remembered run is
            // used without checking it, by read and write transactions alike (I2, S2).
            None => pager.run_with(first, count, Integrity::UseRemembered),
        }
    }
}

impl Drop for Snapshot<'_> {
    fn drop(&mut self) {
        let (free, waiting) = {
            let mut state = self.scratch.lock();
            if self.writer {
                state.writer = None;
            } else if let Ok(index) = state.live.binary_search_by_key(&self.seq, |l| l.seq) {
                state.live.remove(index);
            }
            (state.free_retired(), state.bytes)
        };
        drop(free);
        // The end of a read may let versions go to `krummi.data` (J5); the writer's snapshot ends with its commit,
        // which already asked for a transfer.
        if !self.writer && waiting > 0 {
            self.scratch.shared.signal.raise(waiting);
        }
    }
}

/// The one writer of the scratch area. It stays on the thread that created it and cannot be shared between
/// threads, so no two flushes or publications ever overlap.
pub struct ScratchWriter<'a> {
    snapshot: Snapshot<'a>,
    /// Not `Send`: the writer stays on its thread.
    _guard: MutexGuard<'a, ()>,
    /// Not `Sync`: the writer is never shared.
    _not_shared: PhantomData<Cell<()>>,
}

impl<'a> ScratchWriter<'a> {
    /// The snapshot the writer started from: everything committed before it got its turn (T2).
    pub fn snapshot(&self) -> &Snapshot<'a> {
        &self.snapshot
    }

    /// Has the transfer thread write in place every newest version that no open snapshot is older than, making
    /// the journal durable first (J5), and waits for it. Versions written before a failure leave the scratch area;
    /// the rest stay for a later flush.
    /// Then it frees the retired versions that only the writer's snapshot kept, so that a write that flushes to make
    /// room gets it (J7): `&mut self` ends every reference the writer's snapshot returned.
    pub fn flush(&mut self) -> Result<()> {
        let scratch = self.snapshot.scratch;
        let outcome = scratch.demand(Demand::Flush);
        let free = scratch.lock().free_retired_by_writer();
        drop(free);
        outcome
    }

    /// Commits the payloads of `pages` and the value `runs`, each sealed with
    /// [`seal_run`](crate::format::seal_run) for its first page: seals the pages into the temporary area, puts them
    /// in the journal's queue from there, a run's pages as raw entries (D5 of the large values execution), and
    /// publishes them for the next writer (E2). `created[i]` tells whether the transaction created page `pages[i]`,
    /// zeroed, rather than copying its newest version: the journal keeps what differs from that version, or from
    /// zeros (Y1 of the journal page diffs PRD). Returns the number of the commit, which read snapshots see once it is
    /// durable (E3; [`Scratch::wait_durable`]). On failure nothing is published (J12).
    ///
    /// # Panics
    ///
    /// If `created` and `pages` differ in length.
    pub fn commit(
        &mut self,
        pages: &[(u64, PayloadBuf)],
        created: &[bool],
        runs: &[(u64, RunBuf)],
    ) -> Result<u64> {
        assert_eq!(created.len(), pages.len(), "one flag per page");
        let staged = self.stage(pages, runs)?;
        let scratch = self.snapshot.scratch;
        if let Some(journal) = &scratch.shared.journal {
            let (txid, bases) = {
                let state = scratch.read();
                // The version each copied page comes from is the newest one: in the scratch area while it is there,
                // or else in the store, which no transfer writes again until a newer version exists (J5).
                let bases: Vec<Option<(Arc<Slot>, usize)>> = pages
                    .iter()
                    .zip(created)
                    .map(|((number, _), &created)| {
                        let newest = state.versions.get(number)?.last();
                        newest
                            .filter(|_| !created)
                            .map(|version| (Arc::clone(&version.page), version.index))
                    })
                    .collect();
                (state.last_committed + 1, bases)
            };
            let pager = scratch.pager();
            // The journal reads the sealed pages from their slots (O5 of the performance plan): the staged pages
            // come first, in the order of `pages`, then each run's pages, all created.
            let refs: Vec<JournalPage<'_>> = staged
                .0
                .iter()
                .enumerate()
                .map(|(i, (number, slot, index))| {
                    let page = slot.page_at(*index);
                    if i >= pages.len() {
                        return Ok((number | RAW_ENTRY, page, None));
                    }
                    let base = if created[i] {
                        None
                    } else if let Some((slot, index)) = &bases[i] {
                        Some(slot.page_at(*index))
                    } else {
                        // A page copied without a version here was read from the store. It cannot be missing now:
                        // `stage` checked that the page is inside the store, which only grows while open; if it ever
                        // were, it is damage of the store, not a panic of the writer.
                        let stored = pager
                            .raw_pages(*number, 1)
                            .and_then(|stored| stored.try_into().ok())
                            .ok_or_else(|| pager.damaged(*number))?;
                        Some(stored)
                    };
                    Ok((*number, page, base))
                })
                .collect::<Result<_>>()?;
            journal.enqueue(pager, txid, &refs)?;
        }
        Ok(self.publish(staged))
    }

    /// Seals the payloads of `pages` for their numbers straight into the temporary area, and copies the value `runs`,
    /// each sealed for its first page, into it, a run into contiguous slots (D5), ready to be published (J7). Nothing
    /// is visible yet; dropping the result gives the slots back. The staged pages are those of `pages`, in order,
    /// then those of each run.
    ///
    /// # Panics
    ///
    /// If a page is a header page or beyond the end of the store, or a run is not a whole number of pages.
    pub fn stage(&self, pages: &[(u64, PayloadBuf)], runs: &[(u64, RunBuf)]) -> Result<Staged> {
        let scratch = self.snapshot.scratch;
        let pager = scratch.pager();
        let page_count = pager.page_count();
        let entries = pages.len()
            + runs
                .iter()
                .map(|(_, run)| run.len() / PAGE_SIZE)
                .sum::<usize>();
        let mut staged = Vec::new();
        staged
            .try_reserve_exact(entries)
            .map_err(|_| Error::OutOfMemory {
                requested: (entries * size_of::<(u64, Arc<Slot>, usize)>()) as u64,
            })?;
        for (page_number, payload) in pages {
            assert!(
                (HEADER_PAGES..page_count).contains(page_number),
                "page {page_number} cannot be published"
            );
            let slot = scratch.shared.area.store_with(1, pager, |slot| {
                let page = slot.try_into().expect("one page");
                format::seal_page(*page_number, &payload[..], page);
            })?;
            staged.push((*page_number, Arc::new(slot), 0));
        }
        for (first, run) in runs {
            let count = (run.len() / PAGE_SIZE) as u64;
            assert!(
                count > 0
                    && run.len().is_multiple_of(PAGE_SIZE)
                    && *first >= HEADER_PAGES
                    && first + count <= page_count,
                "the run of {} bytes from page {first} cannot be published",
                run.len()
            );
            let slots = Arc::new(scratch.shared.area.store_run(run, pager)?);
            staged.extend(
                (*first..first + count)
                    .zip(0..)
                    .map(|(n, i)| (n, Arc::clone(&slots), i)),
            );
        }
        Ok(Staged(staged))
    }

    /// Publishes the staged pages as the newest versions, for every writer from now on and for the read snapshots
    /// opened once the commit is durable (T2, E3), and asks the transfer thread to move them to `krummi.data`
    /// (J5). Returns the number of the new version.
    pub fn publish(&mut self, staged: Staged) -> u64 {
        let scratch = self.snapshot.scratch;
        let mut state = scratch.lock();
        let txid = state.last_committed + 1;
        for (page_number, page, index) in staged.0 {
            state.hold(&page);
            let version = Version { txid, page, index };
            let versions = state.versions.entry(page_number).or_default();
            let first = versions.is_empty();
            versions.push(version);
            if first {
                state.filter.added(page_number);
            }
        }
        state.last_committed = txid;
        let bytes = state.bytes;
        drop(state);
        scratch.shared.signal.raise(bytes);
        txid
    }
}

#[cfg(test)]
#[path = "scratch_tests.rs"]
mod tests;
