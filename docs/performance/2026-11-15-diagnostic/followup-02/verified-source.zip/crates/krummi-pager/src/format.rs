//! On-disk format of `krummi.data` (decisions P2–P6 of the Pager PRD).
//!
//! Layout of the two header pages:
//!
//! - page 0: the identification mark (bytes 0..16), then header copy A at byte 64;
//! - page 1: header copy B at byte 0.
//!
//! Format 2 (module 3) adds to each header copy how far the journal has been transferred to `krummi.data`. Format 1
//! copies are still decoded, with their own layout, so that a store of format 1 is refused as an older format and
//! not as damage (J3 of the Journal PRD). Format 3 (the rename to Krummi) changes only the mark and the file names;
//! its header copies have the layout of format 2, so a format 2 header with the new mark is an older format (R5 of
//! the rename-to-krummi PRD).
//!
//! Every other page starts with a 16-byte page header (checksum, page number) followed by its payload. The
//! checksum covers the page number and the payload, so a page written at the wrong position is also detected.
//!
//! Format 7 (D1 of the large values execution, V3 and V9 of the large values PRD) adds value runs: a value that
//! does not fit in its leaf lives in a run of contiguous pages whose first 16 bytes are the only header, with the
//! same layout as a page header but for the whole run: the xxh3-64 of bytes `8..` of the run, then the number of
//! its first page, both little endian. Its interior pages carry no header. A run of one page is a sealed page.
//!
//! Format 8 (M14 of the multi-value trees PRD) adds the multi-value trees, whose entries hold their values or the root
//! of a subtree, little endian like the rest of the format; the pages keep their layout.
//!
//! Format 9 (X12 of the fixed-size trees PRD) adds the fixed-size trees: a catalog entry of a new kind, with the
//! length of the tree's values, and nodes of their own, with their keys and that length little endian; the pages keep
//! their layout.

use zerocopy::little_endian::{U32, U64};
use zerocopy::{FromBytes, Immutable, IntoBytes, KnownLayout};

/// Size of a page in bytes (P2).
pub const PAGE_SIZE: usize = 8192;
/// [`PAGE_SIZE`] as a `u64`, for file offsets.
pub const PAGE_SIZE_U64: u64 = PAGE_SIZE as u64;
/// Format version written by this version of the engine (P5; `5` since the free-space map, F11; `6` since the catalog
/// and the trees, A13 of the trees and key operations PRD; `7` since the values outside their leaf, V9 of the large
/// values PRD; `8` since the multi-value trees, M14 of the multi-value trees PRD; `9` since the fixed-size trees, X12
/// of the fixed-size trees PRD; `10` since the journal keeps the bytes that changed and nodes have holes, Y5 of the
/// journal page diffs PRD; `11` since the tables and the sequences, E20 of the tables with schema PRD).
pub const FORMAT_VERSION: u32 = 11;
/// Identification mark at the start of `krummi.data` (P4). The `\r\n`, `\x1a` and `\n` bytes detect text-mode
/// transfers that would corrupt the file, as in the PNG signature.
pub const MARK: [u8; 16] = *b"\x89Krummi\r\n\x1a\n\0\0\0\0\0";
/// Number of pages that hold the header copies; data pages start after them.
pub const HEADER_PAGES: u64 = 2;
/// Size of the per-page header: checksum and page number.
pub const PAGE_HEADER_SIZE: usize = 16;
/// Bytes of a page available to its user.
pub const PAGE_PAYLOAD_SIZE: usize = PAGE_SIZE - PAGE_HEADER_SIZE;

const HEADER_A_OFFSET: usize = 64;
const HEADER_B_OFFSET: usize = PAGE_SIZE;
/// Byte offsets of the two header copies in `krummi.data`.
pub const HEADER_COPY_OFFSETS: [u64; 2] = [HEADER_A_OFFSET as u64, HEADER_B_OFFSET as u64];

/// A header copy of format 2.
#[repr(C)]
#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Clone, Copy)]
struct RawHeader {
    format_version: U32,
    page_size: U32,
    revision: U64,
    applied_txid: U64,
    journal_first: U64,
    checksum: U64,
}

/// A header copy of format 1 (modules 1 and 2).
#[repr(C)]
#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Clone, Copy)]
struct RawHeaderV1 {
    format_version: U32,
    page_size: U32,
    revision: U64,
    reserved: [u8; 8],
    checksum: U64,
}

/// Size in bytes of an encoded header copy.
pub const RAW_HEADER_SIZE: usize = size_of::<RawHeader>();
const CHECKED_HEADER_BYTES: usize = RAW_HEADER_SIZE - size_of::<U64>();
const CHECKED_HEADER_V1_BYTES: usize = size_of::<RawHeaderV1>() - size_of::<U64>();

/// The decoded content of one header copy.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Header {
    pub format_version: u32,
    pub page_size: u32,
    /// Grows each time the header is written; the intact copy with the highest revision is the current one.
    pub revision: u64,
    /// Last commit whose changes are all in `krummi.data` and flushed to the disk (J6 of the Journal PRD).
    pub applied_txid: u64,
    /// Number of the first journal file that may hold commits after `applied_txid`.
    pub journal_first: u64,
}

impl Header {
    /// The header of a store created by this version of the engine.
    pub fn new_store() -> Header {
        Header {
            format_version: FORMAT_VERSION,
            page_size: PAGE_SIZE as u32,
            revision: 1,
            applied_txid: 0,
            journal_first: 1,
        }
    }

    /// The encoded bytes of one header copy.
    pub fn encode(&self) -> [u8; RAW_HEADER_SIZE] {
        let mut raw = RawHeader {
            format_version: U32::new(self.format_version),
            page_size: U32::new(self.page_size),
            revision: U64::new(self.revision),
            applied_txid: U64::new(self.applied_txid),
            journal_first: U64::new(self.journal_first),
            checksum: U64::new(0),
        };
        raw.checksum = U64::new(xxh3_64(&raw.as_bytes()[..CHECKED_HEADER_BYTES]));
        let mut out = [0; RAW_HEADER_SIZE];
        out.copy_from_slice(raw.as_bytes());
        out
    }

    /// Decodes a header copy, or `None` when its integrity check fails. A copy whose check passes with the
    /// layout of format 1 decodes as a header of that format, without journal data.
    fn decode(bytes: &[u8]) -> Option<Header> {
        let raw = RawHeader::read_from_bytes(bytes.get(..RAW_HEADER_SIZE)?).ok()?;
        if raw.format_version.get() != 1
            && raw.checksum.get() == xxh3_64(&raw.as_bytes()[..CHECKED_HEADER_BYTES])
        {
            return Some(Header {
                format_version: raw.format_version.get(),
                page_size: raw.page_size.get(),
                revision: raw.revision.get(),
                applied_txid: raw.applied_txid.get(),
                journal_first: raw.journal_first.get(),
            });
        }
        let v1 = RawHeaderV1::read_from_bytes(bytes.get(..size_of::<RawHeaderV1>())?).ok()?;
        if v1.checksum.get() != xxh3_64(&v1.as_bytes()[..CHECKED_HEADER_V1_BYTES]) {
            return None;
        }
        Some(Header {
            format_version: v1.format_version.get(),
            page_size: v1.page_size.get(),
            revision: v1.revision.get(),
            applied_txid: 0,
            journal_first: 1,
        })
    }
}

/// Encodes a header copy with the layout of format 1, as the stores of modules 1 and 2 have it (for tests).
pub fn encode_v1(format_version: u32, revision: u64) -> Vec<u8> {
    let mut raw = RawHeaderV1 {
        format_version: U32::new(format_version),
        page_size: U32::new(PAGE_SIZE as u32),
        revision: U64::new(revision),
        reserved: [0; 8],
        checksum: U64::new(0),
    };
    raw.checksum = U64::new(xxh3_64(&raw.as_bytes()[..CHECKED_HEADER_V1_BYTES]));
    raw.as_bytes().to_vec()
}

/// Writes the mark and both header copies into the first two pages of `pages`.
pub fn write_header_pages(pages: &mut [u8], header: &Header) {
    pages[..MARK.len()].copy_from_slice(&MARK);
    let encoded = header.encode();
    pages[HEADER_A_OFFSET..HEADER_A_OFFSET + RAW_HEADER_SIZE].copy_from_slice(&encoded);
    pages[HEADER_B_OFFSET..HEADER_B_OFFSET + RAW_HEADER_SIZE].copy_from_slice(&encoded);
}

/// What the start of a data file says about it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HeaderRead {
    /// The file does not start with the identification mark (D10, P4).
    NotAStore,
    /// The mark is intact, but the header pages are incomplete or no header copy is intact (P6).
    Damaged,
    /// The current header: the intact copy with the highest revision.
    Found(Header),
}

/// Reads the identification mark and the header copies from the start of a data file.
pub fn read_header_pages(start: &[u8]) -> HeaderRead {
    if start.len() < MARK.len() || start[..MARK.len()] != MARK {
        return HeaderRead::NotAStore;
    }
    if start.len() < HEADER_PAGES as usize * PAGE_SIZE {
        return HeaderRead::Damaged;
    }
    let [a, b] = header_copies(start);
    let current = match (a, b) {
        (Some(a), Some(b)) => Some(if b.revision > a.revision { b } else { a }),
        (Some(h), None) | (None, Some(h)) => Some(h),
        (None, None) => None,
    };
    match current {
        // A page size other than ours is not a format this engine ever wrote: treat it as damage.
        Some(h) if h.page_size as usize == PAGE_SIZE => HeaderRead::Found(h),
        _ => HeaderRead::Damaged,
    }
}

/// The two header copies in the header pages at the start of `start`, each `None` when damaged.
///
/// # Panics
///
/// If `start` is shorter than the header pages.
pub fn header_copies(start: &[u8]) -> [Option<Header>; 2] {
    [
        Header::decode(&start[HEADER_A_OFFSET..]),
        Header::decode(&start[HEADER_B_OFFSET..]),
    ]
}

/// The xxh3-64 of `bytes`, the hash of every checksum in the store and its journal. `twox-hash` picks its AVX2, SSE2
/// or scalar code at run time, where `xxhash-rust` fixed it at compile time (O3a of the performance plan); both give
/// the same values.
pub(crate) fn xxh3_64(bytes: &[u8]) -> u64 {
    twox_hash::XxHash3_64::oneshot(bytes)
}

/// The checksum of a page or a run: of everything after the checksum itself.
fn checksum(run: &[u8]) -> u64 {
    xxh3_64(&run[8..])
}

/// Fills `page` with the page header and `payload`; the rest of the payload area is zeroed.
pub fn seal_page(page_number: u64, payload: &[u8], page: &mut [u8; PAGE_SIZE]) {
    assert!(
        payload.len() <= PAGE_PAYLOAD_SIZE,
        "payload of {} bytes does not fit in a page",
        payload.len()
    );
    page[PAGE_HEADER_SIZE..PAGE_HEADER_SIZE + payload.len()].copy_from_slice(payload);
    page[PAGE_HEADER_SIZE + payload.len()..].fill(0);
    seal_run(page_number, page);
}

/// Whether `page` is intact and was written as page `page_number` (G6).
pub fn verify_page(page_number: u64, page: &[u8]) -> bool {
    page.len() == PAGE_SIZE && verify_run(page_number, page)
}

/// Writes the header of a run of `run.len() / PAGE_SIZE` pages starting at page `first`: its first page number and
/// the checksum of the whole run. Its content, after the header, is the caller's, who zeroes what it does not use.
///
/// # Panics
///
/// If `run` is empty or not a whole number of pages.
pub fn seal_run(first: u64, run: &mut [u8]) {
    assert!(
        !run.is_empty() && run.len().is_multiple_of(PAGE_SIZE),
        "a run of {} bytes is not a whole number of pages",
        run.len()
    );
    run[8..16].copy_from_slice(&first.to_le_bytes());
    let checksum = checksum(run);
    run[..8].copy_from_slice(&checksum.to_le_bytes());
}

/// Pages of the run of a value of `len` bytes: its 16-byte header and the value, rounded up to whole pages (D1 of the
/// large values execution), so at most one page more than the value's bytes fill (V5).
pub fn run_pages(len: u64) -> u64 {
    (len + PAGE_HEADER_SIZE as u64).div_ceil(PAGE_SIZE_U64)
}

/// The checksum that a page or a run records, its first 8 bytes; [`verify_run`] checks that it matches the content.
///
/// # Panics
///
/// If `run` is shorter than 8 bytes.
pub fn recorded_checksum(run: &[u8]) -> u64 {
    u64::from_le_bytes(run[..8].try_into().expect("8 bytes"))
}

/// Whether `run` is an intact run written at page `first`, with exactly its length (G6, V7).
pub fn verify_run(first: u64, run: &[u8]) -> bool {
    !run.is_empty()
        && run.len().is_multiple_of(PAGE_SIZE)
        && run[8..16] == first.to_le_bytes()
        && run[..8] == checksum(run).to_le_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Values recorded with `xxhash-rust` 0.8.19, the crate that wrote every existing store (O3a of the performance
    /// plan). The lengths cover each of xxh3's input classes (0, 1–3, 4–8, 9–16, 17–128, 129–240, longer) at their
    /// edges, a journal record header (56), a page without its checksum (8,184), a page and a run of 12 pages.
    #[test]
    fn xxh3_keeps_the_values_of_the_stored_format() {
        let recorded = [
            (0, 0x2d06_8005_38d3_94c2),
            (1, 0xc44b_dff4_074e_ecdb),
            (3, 0xa1c4_a825_9b82_7291),
            (4, 0xbb4e_3d89_ee0b_271d),
            (8, 0x79d0_2238_b80e_37b1),
            (9, 0xf64c_ecc4_271f_f461),
            (16, 0x222e_9aea_d6bd_dd51),
            (17, 0x47aa_d6b3_75eb_4bba),
            (56, 0xf9c9_dc3a_32cf_9d0b),
            (128, 0x421a_9c90_5c6e_66ba),
            (129, 0x9e24_1480_0f83_768a),
            (240, 0xb714_c5fd_2274_4964),
            (241, 0xbc42_4a2c_480d_d281),
            (8_184, 0x9791_3c4e_003f_6213),
            (8_192, 0x4583_0b92_71bf_697a),
            (98_304, 0x6dc9_3d83_b430_09f0),
        ];
        for (len, value) in recorded {
            assert_eq!(xxh3_64(&xxh3_input(len)), value, "{len} bytes");
        }
    }

    /// Bytes that are not periodic in any short stride, so every lane of the hash reads different values.
    fn xxh3_input(len: usize) -> Vec<u8> {
        (0..len as u64)
            .map(|i| (i.wrapping_mul(2_654_435_761) >> 13) as u8)
            .collect()
    }

    fn header_pages(header: &Header) -> Vec<u8> {
        let mut pages = vec![0; HEADER_PAGES as usize * PAGE_SIZE];
        write_header_pages(&mut pages, header);
        pages
    }

    #[test]
    fn header_pages_round_trip() {
        let pages = header_pages(&Header::new_store());
        assert_eq!(
            read_header_pages(&pages),
            HeaderRead::Found(Header::new_store())
        );
        assert_eq!(Header::new_store().format_version, 11);
    }

    #[test]
    fn a_format_1_copy_decodes_as_format_1() {
        let mut pages = header_pages(&Header::new_store());
        let v1 = encode_v1(1, 3);
        for offset in [HEADER_A_OFFSET, HEADER_B_OFFSET] {
            pages[offset..offset + v1.len()].copy_from_slice(&v1);
            pages[offset + v1.len()..offset + RAW_HEADER_SIZE].fill(0);
        }
        match read_header_pages(&pages) {
            HeaderRead::Found(h) => assert_eq!((h.format_version, h.revision), (1, 3)),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn a_file_without_the_mark_is_not_a_store() {
        let mut pages = header_pages(&Header::new_store());
        pages[3] ^= 0xFF;
        assert_eq!(read_header_pages(&pages), HeaderRead::NotAStore);
        assert_eq!(read_header_pages(&[]), HeaderRead::NotAStore);
        assert_eq!(read_header_pages(&MARK[..10]), HeaderRead::NotAStore);
    }

    #[test]
    fn the_mark_with_incomplete_header_pages_is_damage() {
        let pages = header_pages(&Header::new_store());
        assert_eq!(
            read_header_pages(&pages[..PAGE_SIZE + 10]),
            HeaderRead::Damaged
        );
    }

    #[test]
    fn one_damaged_copy_is_tolerated_and_two_are_damage() {
        let header = Header::new_store();
        for offset in [HEADER_A_OFFSET, HEADER_B_OFFSET] {
            let mut pages = header_pages(&header);
            pages[offset + 2] ^= 0x01;
            assert_eq!(
                read_header_pages(&pages),
                HeaderRead::Found(header),
                "copy at {offset}"
            );
        }
        let mut pages = header_pages(&header);
        pages[HEADER_A_OFFSET + 5] ^= 0x01;
        pages[HEADER_B_OFFSET + 5] ^= 0x01;
        assert_eq!(read_header_pages(&pages), HeaderRead::Damaged);
    }

    #[test]
    fn the_copy_with_the_highest_revision_wins() {
        let mut pages = header_pages(&Header::new_store());
        let newer = Header {
            revision: 7,
            ..Header::new_store()
        };
        pages[HEADER_B_OFFSET..HEADER_B_OFFSET + RAW_HEADER_SIZE].copy_from_slice(&newer.encode());
        assert_eq!(read_header_pages(&pages), HeaderRead::Found(newer));
    }

    #[test]
    fn every_byte_of_a_header_copy_is_covered_by_its_check() {
        let header = Header::new_store();
        for byte in 0..RAW_HEADER_SIZE {
            let mut encoded = header.encode();
            encoded[byte] ^= 0x10;
            assert_eq!(Header::decode(&encoded), None, "byte {byte}");
        }
    }

    #[test]
    fn a_sealed_page_verifies_and_any_flipped_byte_does_not() {
        let mut page = [0; PAGE_SIZE];
        seal_page(5, b"hello", &mut page);
        assert!(verify_page(5, &page));
        assert!(
            !verify_page(6, &page),
            "a page read at the wrong position is damage"
        );
        for byte in [0, 7, 8, 15, 16, 20, PAGE_SIZE - 1] {
            let mut flipped = page;
            flipped[byte] ^= 0x01;
            assert!(!verify_page(5, &flipped), "byte {byte}");
        }
    }

    /// A run of `pages` pages sealed for `first`, with a recognizable value after its header.
    fn sealed_run(first: u64, pages: usize) -> Vec<u8> {
        let mut run = vec![0; pages * PAGE_SIZE];
        let value_len = run.len() - PAGE_HEADER_SIZE - 100;
        for (i, b) in run[PAGE_HEADER_SIZE..PAGE_HEADER_SIZE + value_len]
            .iter_mut()
            .enumerate()
        {
            *b = (i * 7 + 3) as u8;
        }
        seal_run(first, &mut run);
        run
    }

    #[test]
    fn a_sealed_run_verifies_and_a_flipped_byte_in_any_of_its_pages_does_not() {
        let run = sealed_run(9, 3);
        assert!(verify_run(9, &run));
        assert_eq!(
            run[8..16],
            9u64.to_le_bytes(),
            "the first page number, little endian"
        );
        assert!(
            !verify_run(10, &run),
            "a run read at the wrong position is damage"
        );
        assert!(
            !verify_run(9, &run[..2 * PAGE_SIZE]),
            "a run read shorter is damage"
        );
        for byte in [
            0,
            7,
            8,
            15,
            16,
            PAGE_SIZE - 1,
            PAGE_SIZE + 123,
            2 * PAGE_SIZE,
            3 * PAGE_SIZE - 1,
        ] {
            let mut flipped = run.clone();
            flipped[byte] ^= 0x01;
            assert!(!verify_run(9, &flipped), "byte {byte}");
        }
    }

    #[test]
    fn a_one_page_run_is_a_sealed_page() {
        let run = sealed_run(5, 1);
        assert!(verify_page(5, &run));
        let mut page = [0; PAGE_SIZE];
        seal_page(5, b"hello", &mut page);
        assert!(verify_run(5, &page));
    }

    #[test]
    fn an_empty_or_partial_run_does_not_verify() {
        assert!(!verify_run(3, &[]));
        let run = sealed_run(3, 2);
        assert!(!verify_run(3, &run[..PAGE_SIZE + 10]));
        assert!(!verify_run(3, &vec![0; 2 * PAGE_SIZE]));
    }

    #[test]
    fn a_never_written_page_does_not_verify() {
        assert!(!verify_page(3, &[0; PAGE_SIZE]));
    }
}
