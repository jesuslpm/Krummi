//! The Pager of Krummi (module 1): the paged data file every other module reads and writes through.
//!
//! This crate is the only part of the engine allowed to use unsafe code (D12 of the root PRD). Its API is
//! internal to the engine: applications use the `krummi` crate.

mod checked;
mod error;
pub mod format;
mod journal;
mod pager;
mod random;
mod recovery;
mod remembered;
mod scratch;
mod sys;
mod temp;
mod transfer;

pub use checked::{CHECKED_SLOTS, set_remember_checked};
pub use error::{
    Error, ErrorKind, Result, SchemaDifference, SchemaRule, SizeSubject, TreeKind, ValueRule,
};
pub use journal::{JOURNAL_PREFIX, RELEASE_FILE_LIMIT};
pub use pager::{
    DATA_FILE, INITIAL_SIZE, Info, Integrity, MAX_GROWTH_STEP, MIN_MAX_SIZE, NEW_DATA_FILE,
    OpenOptions, Pager, TEMPORARY_RESERVATION, growth_target,
};
pub use random::fill_random;
pub use scratch::{
    Memory, Origin, PayloadBuf, RunBuf, Scratch, ScratchWriter, Snapshot, Staged, alloc_payload,
    alloc_run, reuse_payload, try_reserve,
};
pub use temp::TEMP_DIR;

/// Fault injection for the tests of the engine crates (feature `test-hooks`). Faults are per thread; a thread can
/// share another's with [`testing::adopt`], as the journal's writer does with the thread that opened the store.
#[cfg(feature = "test-hooks")]
pub mod testing {
    pub use crate::checked::with_checked_slots;
    pub use crate::journal::entry_sizes;
    pub use crate::remembered::with_remembered_commits_failing;
    pub use crate::sys::Op;
    pub use crate::sys::faults::{
        Action, Context, Model, Recorded, abort_at, adopt, context, count, inject, materialize,
        points, recorded_len, reset, skip_syncs, start_recording, take_recording,
    };
}
