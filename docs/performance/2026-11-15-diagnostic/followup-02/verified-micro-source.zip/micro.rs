use std::{borrow::Cow,hint::black_box,sync::Arc,time::Instant};
use krummi::{Column,Schema,Store,StoreOptions,TableMode};
use krummi::ids::Ulid;
use krummi::table::{Projection,Col,TextBytes,Timestamp,ProjectedRow};
use krummi::table::value::{ColumnType as C,Value as V};

struct Handles {id:Col<Ulid>,n:Col<i64>,x:Col<f64>,ts:Col<Timestamp>,flag:Col<bool>,name:Col<TextBytes>}
impl Handles {
    #[inline(never)] fn new(p:&Projection)->Self {Self{id:p.column(0).unwrap(),n:p.column(1).unwrap(),x:p.column(2).unwrap(),ts:p.column(3).unwrap(),flag:p.column(4).unwrap(),name:p.column(5).unwrap()}}
}
#[inline(never)]
fn access<const MODE:u8>(r:&ProjectedRow<'_,'_>,h:&Handles)->u64 {
    let (id,n,x,ts,flag,name)=if MODE==1 {
        (r.ulid(0),r.i64(1),r.f64(2),r.timestamp(3),r.bool(4),r.text_bytes(5))
    } else if MODE==2 {
        (r.get(&h.id),r.get(&h.n),r.get(&h.x),r.get(&h.ts),r.get(&h.flag),r.get(&h.name))
    } else if MODE==3 {
        (r.diagnostic_no_tag::<Ulid>(0),r.diagnostic_no_tag::<i64>(1),r.diagnostic_no_tag::<f64>(2),r.diagnostic_no_tag::<Timestamp>(3),r.diagnostic_no_tag::<bool>(4),r.diagnostic_no_tag::<TextBytes>(5))
    } else {
        (r.diagnostic_no_handle_owner(&h.id),r.diagnostic_no_handle_owner(&h.n),r.diagnostic_no_handle_owner(&h.x),r.diagnostic_no_handle_owner(&h.ts),r.diagnostic_no_handle_owner(&h.flag),r.diagnostic_no_handle_owner(&h.name))
    };
    id.unwrap().unwrap().0[0] as u64 ^ n.unwrap().unwrap() as u64 ^ x.unwrap().unwrap().to_bits() ^ ts.unwrap().unwrap() as u64 ^ flag.unwrap().unwrap() as u64 ^ name.unwrap().unwrap()[0] as u64
}
fn main() {
    let store=Store::open_temporary(&StoreOptions::default()).unwrap();
    let schema=Schema::new(vec![Column::new("id",C::Ulid).not_null(),Column::new("n",C::I64).not_null(),Column::new("x",C::F64).not_null(),Column::new("ts",C::Timestamp).not_null(),Column::new("flag",C::Bool).not_null(),Column::new("name",C::String).not_null()],&["id"]);
    let mut w=store.write().unwrap();let t=w.open_table_with("table",TableMode::CreateNew(&schema)).unwrap();
    w.insert_row(&t,&[("id",V::Ulid(Ulid([5;16]))),("n",V::I64(42)),("x",V::F64(1.25)),("ts",V::Timestamp(123456000)),("flag",V::Bool(true)),("name",V::String(Cow::Borrowed("runtime prepared row")))]).unwrap();w.commit().unwrap();
    let tx=store.read().unwrap();let clock=Instant::now();let table=tx.open_table("table").unwrap();println!("metric first_schema_open 1 {}",clock.elapsed().as_nanos());
    let names=black_box(["id","n","x","ts","flag","name"]);
    let clock=Instant::now();let p=black_box(table.projection(&names).unwrap());println!("metric first_projection 1 {}",clock.elapsed().as_nanos());
    let clock=Instant::now();let h=black_box(Handles::new(&p));println!("metric first_handles 1 {}",clock.elapsed().as_nanos());
    let tx2=store.read().unwrap();let t2=tx2.open_table("table").unwrap();assert!(Arc::ptr_eq(&p,&t2.projection(&names).unwrap()));
    let row=tx.get_row(&table,&[V::Ulid(Ulid([5;16]))]).unwrap().unwrap();let r=p.read(&row).unwrap();
    let expect=access::<1>(&r,&h);assert_eq!(expect,access::<2>(&r,&h));assert_eq!(expect,access::<3>(&r,&h));assert_eq!(expect,access::<4>(&r,&h));
    for round in 0..8 {
        let prepare=20_000;
        for mode in if round%2==0 {[0,1,2]} else {[2,1,0]} {
            let clock=Instant::now();
            for _ in 0..prepare {match mode {
                0=>{black_box(table.prepare_projection_uncached(black_box(&names)).unwrap());},
                1=>{black_box(table.projection(black_box(&names)).unwrap());},
                _=>{black_box(Handles::new(black_box(&p)));},
            }}
            println!("sample {round} {} {prepare} {}",["prepare_uncached","cache_hit","handles_prepare"][mode],clock.elapsed().as_nanos());
        }
        let n=2_000_000u64;
        let order=if round%2==0 {[1,2,3,4,5,6]} else {[6,5,4,3,2,1]};
        for mode in order {
            let clock=Instant::now();let mut sum=0u64;
            match mode {
                1=>for _ in 0..n {sum=sum.wrapping_add(access::<1>(black_box(&r),black_box(&h)));},
                2=>for _ in 0..n {sum=sum.wrapping_add(access::<2>(black_box(&r),black_box(&h)));},
                3=>for _ in 0..n {sum=sum.wrapping_add(access::<3>(black_box(&r),black_box(&h)));},
                4=>for _ in 0..n {sum=sum.wrapping_add(access::<4>(black_box(&r),black_box(&h)));},
                5=>for _ in 0..n {black_box(black_box(&p).read(black_box(&row)).unwrap());},
                6=>for _ in 0..n {black_box(black_box(&p).diagnostic_read_without_schema(black_box(&row)).unwrap());},
                _=>unreachable!(),
            }
            black_box(sum);
            println!("sample {round} {} {n} {}",["","index_6","handles_6","index_no_tag_6","handles_no_owner_6","read","read_no_schema"][mode],clock.elapsed().as_nanos());
        }
    }
    // Old-version plans are published once, from the layout the ordinary row decoder already resolved.
    let mut w=store.write().unwrap();let wt=w.open_table("table").unwrap();w.add_column(&wt,&Column::new("added",C::I64)).unwrap();w.commit().unwrap();
    let oldtx=store.read().unwrap();let oldtable=oldtx.open_table("table").unwrap();let oldp=oldtable.projection(&names).unwrap();
    let oldrow=oldtx.get_row(&oldtable,&[V::Ulid(Ulid([5;16]))]).unwrap().unwrap();
    let clock=Instant::now();black_box(oldp.read(&oldrow).unwrap());println!("metric first_old_version 1 {}",clock.elapsed().as_nanos());
    for round in 0..8 {let n=2_000_000;let clock=Instant::now();for _ in 0..n {black_box(black_box(&oldp).read(black_box(&oldrow)).unwrap());}println!("sample {round} read_old_warm {n} {}",clock.elapsed().as_nanos());}
}
