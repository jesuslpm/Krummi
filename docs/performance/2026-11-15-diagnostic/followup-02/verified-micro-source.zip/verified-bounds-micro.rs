use std::{borrow::Cow,hint::black_box,sync::Arc,time::Instant};
use krummi::{Column,Schema,Store,StoreOptions,TableMode};
use krummi::ids::Ulid;
use krummi::table::{Projection,Col,TextBytes,Timestamp,ProjectedRow};
use krummi::table::value::{ColumnType as C,Value as V};

struct Handles {id:Col<Ulid>,n:Col<i64>,x:Col<f64>,ts:Col<Timestamp>,flag:Col<bool>,name:Col<TextBytes>}
impl Handles {
    #[inline(never)] fn new(p:&Projection)->Self {Self{id:p.column(0).unwrap(),n:p.column(1).unwrap(),x:p.column(2).unwrap(),ts:p.column(3).unwrap(),flag:p.column(4).unwrap(),name:p.column(5).unwrap()}}
}
#[inline(never)]
fn access<const MODE:u8>(r:&ProjectedRow<'_,'_>,h:&Handles)->u64 {
    let (id,n,x,ts,flag,name)=if MODE==1 {
        (r.ulid(0),r.i64(1),r.f64(2),r.timestamp(3),r.bool(4),r.text_bytes(5))
    } else if MODE==2 {
        (r.get(&h.id),r.get(&h.n),r.get(&h.x),r.get(&h.ts),r.get(&h.flag),r.get(&h.name))
    } else if MODE==3 {
        (r.diagnostic_no_tag::<Ulid>(0),r.diagnostic_no_tag::<i64>(1),r.diagnostic_no_tag::<f64>(2),r.diagnostic_no_tag::<Timestamp>(3),r.diagnostic_no_tag::<bool>(4),r.diagnostic_no_tag::<TextBytes>(5))
    } else {
        (r.diagnostic_no_handle_owner(&h.id),r.diagnostic_no_handle_owner(&h.n),r.diagnostic_no_handle_owner(&h.x),r.diagnostic_no_handle_owner(&h.ts),r.diagnostic_no_handle_owner(&h.flag),r.diagnostic_no_handle_owner(&h.name))
    };
    id.unwrap().unwrap().0[0] as u64 ^ n.unwrap().unwrap() as u64 ^ x.unwrap().unwrap().to_bits() ^ ts.unwrap().unwrap() as u64 ^ flag.unwrap().unwrap() as u64 ^ name.unwrap().unwrap()[0] as u64
}

struct Cells<'b,'r> {
 id:krummi::table::ProjectionCell<'b,'r,Ulid>,n:krummi::table::ProjectionCell<'b,'r,i64>,x:krummi::table::ProjectionCell<'b,'r,f64>,
 ts:krummi::table::ProjectionCell<'b,'r,Timestamp>,flag:krummi::table::ProjectionCell<'b,'r,bool>,name:krummi::table::ProjectionCell<'b,'r,TextBytes>,
}
#[inline(never)] fn cells_value(c:&Cells<'_,'_>)->u64 {
 c.id.read().unwrap().0[0] as u64 ^ c.n.read().unwrap() as u64 ^ c.x.read().unwrap().to_bits() ^ c.ts.read().unwrap() as u64 ^ c.flag.read().unwrap() as u64 ^ c.name.read().unwrap()[0] as u64
}
fn main() {
    let store=Store::open_temporary(&StoreOptions::default()).unwrap();
    let schema=Schema::new(vec![Column::new("id",C::Ulid).not_null(),Column::new("n",C::I64).not_null(),Column::new("x",C::F64).not_null(),Column::new("ts",C::Timestamp).not_null(),Column::new("flag",C::Bool).not_null(),Column::new("name",C::String).not_null()],&["id"]);
    let mut w=store.write().unwrap();let t=w.open_table_with("table",TableMode::CreateNew(&schema)).unwrap();
    w.insert_row(&t,&[("id",V::Ulid(Ulid([5;16]))),("n",V::I64(42)),("x",V::F64(1.25)),("ts",V::Timestamp(123456000)),("flag",V::Bool(true)),("name",V::String(Cow::Borrowed("runtime prepared row")))]).unwrap();w.commit().unwrap();
    let tx=store.read().unwrap();let clock=Instant::now();let table=tx.open_table("table").unwrap();println!("metric first_schema_open 1 {}",clock.elapsed().as_nanos());
    let names=black_box(["id","n","x","ts","flag","name"]);
    let clock=Instant::now();let p=black_box(table.projection(&names).unwrap());println!("metric first_projection 1 {}",clock.elapsed().as_nanos());
    let clock=Instant::now();let h=black_box(Handles::new(&p));println!("metric first_handles 1 {}",clock.elapsed().as_nanos());
    let tx2=store.read().unwrap();let t2=tx2.open_table("table").unwrap();assert!(Arc::ptr_eq(&p,&t2.projection(&names).unwrap()));
    let row=tx.get_row(&table,&[V::Ulid(Ulid([5;16]))]).unwrap().unwrap();let r=p.read(&row).unwrap();
    let expect=access::<1>(&r,&h);assert_eq!(expect,access::<2>(&r,&h));assert_eq!(expect,access::<3>(&r,&h));assert_eq!(expect,access::<4>(&r,&h));

    let cells=Cells{id:r.diagnostic_cell(&h.id).unwrap(),n:r.diagnostic_cell(&h.n).unwrap(),x:r.diagnostic_cell(&h.x).unwrap(),ts:r.diagnostic_cell(&h.ts).unwrap(),flag:r.diagnostic_cell(&h.flag).unwrap(),name:r.diagnostic_cell(&h.name).unwrap()};
    assert_eq!(cells_value(&cells),expect);
    for round in 0..8 {
      let n=2_000_000u64;
      for mode in if round%2==0 {[0,1]} else {[1,0]} {
        let clock=Instant::now();let mut sum=0u64;
        if mode==0 {for _ in 0..n {sum=sum.wrapping_add(access::<4>(black_box(&r),black_box(&h)));}}
        else {for _ in 0..n {sum=sum.wrapping_add(cells_value(black_box(&cells)));}}
        black_box(sum);
        println!("sample {round} {} {n} {}",["lookup_bounds_6","hoisted_cells_6"][mode],clock.elapsed().as_nanos());
      }
    }
}
