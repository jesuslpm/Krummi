use std::borrow::Cow;
use krummi::{Column,Schema,Store,StoreOptions,TableMode,DiagnosticProjection,DiagnosticI64,DiagnosticTextBytes,DiagnosticBool,DiagnosticUlid};
use krummi::ids::Ulid;
use krummi::table::value::{ColumnType,Value};

#[test]
fn prepared_runtime_offsets_versions_null_defaults_and_borrows() {
    fn send_sync<T:Send+Sync>(){}
    send_sync::<DiagnosticProjection>();
    let store=Store::open_temporary(&StoreOptions::default()).unwrap();
    let schema=Schema::new(vec![Column::new("id",ColumnType::Ulid).not_null(),Column::new("name",ColumnType::String),Column::new("n",ColumnType::I64)],&["id"]);
    let id1=Ulid([1;16]);let id2=Ulid([2;16]);
    let mut write=store.write().unwrap();
    let table=write.open_table_with("rows",TableMode::CreateNew(&schema)).unwrap();
    write.insert_row(&table,&[("id",Value::Ulid(id1)),("name",Value::String(Cow::Borrowed("old"))),("n",Value::Null)]).unwrap();
    write.commit().unwrap();
    let mut write=store.write().unwrap();
    let table=write.open_table("rows").unwrap();
    write.add_column(&table,&Column::new("added",ColumnType::String).not_null().with_default(Value::String(Cow::Borrowed("borrowed default")))).unwrap();
    write.add_column(&table,&Column::new("flag",ColumnType::Bool).not_null().with_default(Value::Bool(true))).unwrap();
    write.insert_row(&table,&[("id",Value::Ulid(id2)),("name",Value::Null),("n",Value::I64(7)),("added",Value::String(Cow::Borrowed("new value"))),("flag",Value::Bool(false))]).unwrap();
    write.commit().unwrap();
    let tx=store.read().unwrap();let table=tx.open_table("rows").unwrap();
    let old=tx.get_row(&table,&[Value::Ulid(id1)]).unwrap().unwrap();
    let current=tx.get_row(&table,&[Value::Ulid(id2)]).unwrap().unwrap();
    let mut projection=DiagnosticProjection::new(&old);
    let name=projection.column::<DiagnosticTextBytes>(std::hint::black_box("name")).unwrap();
    let added=projection.column::<DiagnosticTextBytes>("added").unwrap();
    let number=projection.column::<DiagnosticI64>("n").unwrap();
    let flag=projection.column::<DiagnosticBool>("flag").unwrap();
    let id=projection.column::<DiagnosticUlid>("id").unwrap();
    assert!(projection.column::<DiagnosticI64>("name").is_none());
    assert!(projection.column::<DiagnosticBool>("missing").is_none());
    for row in [&old,&current,&old] {
        let bound=projection.bind(row);
        assert_eq!(bound.get(number),row.i64(2));
        assert_eq!(bound.get(flag),row.bool(4));
        assert_eq!(bound.get(id),row.ulid(0));
        assert_eq!(bound.get(name),row.text_bytes(1));
        let a=bound.get(added).unwrap();let b=row.text_bytes(3).unwrap();
        assert!(matches!(a,Cow::Borrowed(_)));assert_eq!(a.as_ptr(),b.as_ptr());assert_eq!(a,b);
    }
    let owned=current.into_owned();
    let bound=projection.bind(&owned);assert_eq!(bound.get(number),Some(7));assert_eq!(bound.get(added).unwrap().as_ref(),b"new value");
}
