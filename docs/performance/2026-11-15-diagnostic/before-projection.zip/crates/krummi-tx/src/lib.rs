//! Transactions of Krummi (module 2): read transactions that see a snapshot, one write transaction at a time and
//! the queue of those waiting for it (Transactions PRD, T1–T18).
//!
//! The crate is internal to the engine. Its page API (`page`, `page_mut`, `allocate`, `free`), its value runs
//! (`allocate_value_run`, `run`, `free`; D4 and D5 of the large values execution) and the meta page's slots (`slot`,
//! `set_slot`) are for the engine's own modules and tests; applications use the `krummi` crate, which exposes only
//! opening, committing and aborting transactions (T1).

mod map;
mod space;
mod transaction;

#[cfg(test)]
mod bytes_tests;
#[cfg(test)]
mod payload_tests;

use std::collections::VecDeque;
use std::io;
use std::path::{Path, PathBuf};
#[cfg(feature = "test-hooks")]
use std::sync::atomic::AtomicBool;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Condvar, Mutex, MutexGuard, PoisonError};
use std::thread::{self, ThreadId};
use std::time::{Duration, Instant};

pub use krummi_pager::format::run_pages;
use krummi_pager::format::{HEADER_PAGES, PAGE_PAYLOAD_SIZE};
pub use krummi_pager::{
    Error, ErrorKind, Info, Memory, OpenOptions, Result, TreeKind, try_reserve,
};
use krummi_pager::{Pager, PayloadBuf, Scratch};
pub use space::REGION_PAGES;
use space::Space;
pub use transaction::{ReadTransaction, WriteTransaction};

/// Page that keeps the transaction layer's own data: the frontier, the first page never used (F3 of the
/// free-space PRD), and the number of free pages of the map (F10). It is an ordinary data page, not part of the
/// header (T17); a blank one is a store where nothing was committed yet.
///
/// Layout of its payload, little-endian: bytes 0–7 the frontier, 8–15 the free pages of the map, and from byte 16
/// the [`META_SLOTS`] slots of the layers above, 8 bytes each; the rest is zero.
pub const META_PAGE: u64 = HEADER_PAGES;
/// Number of `u64` slots the meta page keeps for the layers above (the trees keep their catalog's root and the
/// next tree identity there). A slot never set reads `0`; read transactions see the slots of their snapshot, and
/// a write's changes travel with its commit (T2, T10).
pub const META_SLOTS: usize = 4;
/// Offset of the first slot in the meta page's payload.
const SLOTS_OFFSET: usize = 16;
/// The map page of the first region, after the header and the meta page (F2).
pub const MAP_PAGE: u64 = META_PAGE + 1;
/// First page that write transactions reserve.
pub const FIRST_PAGE: u64 = MAP_PAGE + 1;
/// Bytes of a page that a transaction can use.
pub const PAYLOAD_SIZE: usize = PAGE_PAYLOAD_SIZE;

/// What a transaction's read of a page tells the layers above for the check of its layout (C2, C3 of the remembered
/// node layout check PRD, S1 of the writer checks PRD).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PageCheck {
    /// A page of the store, with the integrity code stored in it as read, which this read verified or a read of this
    /// opening already did (I2 of the remembered page integrity PRD, S2 of the writer checks PRD): the store's memory
    /// of checked contents applies.
    Verified(u64),
    /// A page the write transaction changed: the transaction never checks its layout, which later transactions
    /// check on their first read of what it committed (H1 of the commit checks PRD). It never uses the store's memory
    /// of checked contents, although it keeps the integrity code of the page it was copied from.
    Changed,
    /// A committed version in the scratch area, which no read verifies (I3), and whether its layout already passed
    /// the check of the layers above since it was published (U1 of the version checks PRD).
    Version {
        /// The version passed the layout check.
        checked: bool,
    },
    /// A page whose source tells nothing: its layout is checked on every read.
    Unverified,
}

impl From<krummi_pager::Origin> for PageCheck {
    fn from(origin: krummi_pager::Origin) -> PageCheck {
        match origin {
            krummi_pager::Origin::Store(code) => PageCheck::Verified(code),
            krummi_pager::Origin::Version { checked } => PageCheck::Version { checked },
        }
    }
}

/// What a write transaction records of the pages it changes, while a test asks it to (tests of the writer checks
/// PRD, see [`WriteTransaction::record_layout`]).
#[cfg(feature = "test-hooks")]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LayoutEvent {
    /// The page was created, or handed out to be changed.
    Change(u64),
    /// A layer above read the page, which the transaction changed, to check it.
    Read(u64),
    /// A layer above checked the layout of the page, read without a verified integrity code.
    Check(u64),
}

/// A point of a commit or of the hand-off of the write turn where tests can stop or interrupt the engine
/// (AC-T5, AC-T18, AC-T19, AC-E6). The first three come before the commit's point of no return, when it enters the
/// journal's queue (E2 of the grouped journal PRD); the others after it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Point {
    /// The commit starts.
    CommitFlush,
    /// The commit is about to seal its pages.
    CommitSeal,
    /// The commit is about to write its pages to the temporary area and the journal's queue and publish them.
    CommitPublish,
    /// The commit passed its point of no return and is about to release the turn.
    CommitQueued,
    /// A write transaction ended and others are waiting for the turn.
    Handoff,
    /// The commit released the turn and is about to wait until it is durable.
    CommitWait,
}

#[cfg(feature = "test-hooks")]
type Hook = std::sync::Arc<dyn Fn(Point) + Send + Sync>;

/// An open store with its transactions.
pub struct Engine {
    scratch: Scratch,
    folder: Option<PathBuf>,
    max_size: Option<u64>,
    /// The write turn, shared with the journal's writer, which wakes the waiting requests when it fails (T12).
    turns: Arc<Turns>,
    /// Free space: the frontier, the free pages and the regions' maps.
    space: Space,
    /// Page payloads of earlier commits, for the copies of the next transactions (candidate 4 of the writes
    /// diagnosis, performance plan). Only a store on disk keeps them: a temporary store's memory all counts against
    /// its maximum size (P10, T14).
    payloads: Mutex<Vec<PayloadBuf>>,
    #[cfg(feature = "test-hooks")]
    hook: Mutex<Option<Hook>>,
    /// The page operation of write transactions that fails next, counting down, with the failure it gets (tests).
    #[cfg(feature = "test-hooks")]
    page_fault: Mutex<Option<(u64, Error)>>,
}

/// The most page payloads a store keeps for the next copies: 32 MiB, as the journal keeps for its records.
const SPARE_PAYLOADS: usize = (32 << 20) / PAGE_PAYLOAD_SIZE;

struct Turns {
    queue: Mutex<Queue>,
    /// Times a request waiting for the turn woke up (tests).
    wakeups: AtomicU64,
}

impl Turns {
    /// The store refuses writes (T12): the requests waiting for the turn fail at once, and so do new ones.
    fn refuse_writes(&self) {
        let mut queue = self.queue.lock().unwrap_or_else(PoisonError::into_inner);
        queue.io_failed = true;
        for waiter in &queue.waiting {
            waiter.wake.notify_one();
        }
    }
}

struct Queue {
    /// Thread that holds the write transaction.
    owner: Option<ThreadId>,
    /// The requests waiting for the turn, in order of arrival (T3).
    waiting: VecDeque<Waiter>,
    next_ticket: u64,
    /// The store refuses writes after a failed write (T12).
    io_failed: bool,
}

/// A request waiting for the turn, with the condition variable only it waits on, so that handing the turn over
/// wakes the request that gets it and nobody else.
struct Waiter {
    ticket: u64,
    wake: Arc<Condvar>,
}

impl Queue {
    /// Wakes the first request in the queue, which gets the turn if it is free (T3).
    fn wake_next(&self) {
        if let Some(waiter) = self.waiting.front() {
            waiter.wake.notify_one();
        }
    }
}

impl Engine {
    /// Opens the store in `folder` (flow of the Pager PRD) and reads the transaction layer's data.
    pub fn open(folder: impl AsRef<Path>, options: &OpenOptions) -> Result<Engine> {
        let folder = folder.as_ref();
        let pager = Pager::open(folder, options)?;
        Engine::new(pager, Some(folder.to_path_buf()))
    }

    /// Opens a store that lives only in memory (G9, T15).
    pub fn open_temporary(options: &OpenOptions) -> Result<Engine> {
        Engine::new(Pager::open_temporary(options)?, None)
    }

    fn new(pager: Pager, folder: Option<PathBuf>) -> Result<Engine> {
        let scratch = Scratch::open(pager)?;
        let pager = scratch.pager();
        let fresh = meta_is_blank(pager);
        let (frontier, free) = if fresh {
            (FIRST_PAGE, 0)
        } else {
            let meta = pager.page(META_PAGE)?;
            let frontier = meta_field(meta, 0);
            if frontier < FIRST_PAGE {
                return Err(Error::Damaged {
                    folder,
                    page: Some(META_PAGE),
                });
            }
            (frontier, meta_field(meta, 8))
        };
        let turns = Arc::new(Turns {
            queue: Mutex::new(Queue {
                owner: None,
                waiting: VecDeque::new(),
                next_ticket: 0,
                io_failed: false,
            }),
            wakeups: AtomicU64::new(0),
        });
        // The journal's writer calls it when a group fails: the store already refuses writes, and the writer has
        // woken its own waiters (E8).
        let woken = Arc::clone(&turns);
        scratch.set_failure_hook(Some(Arc::new(move || woken.refuse_writes())));
        Ok(Engine {
            max_size: pager.info().max_size,
            scratch,
            folder,
            turns,
            space: Space::new(frontier, free, !fresh),
            payloads: Mutex::new(Vec::new()),
            #[cfg(feature = "test-hooks")]
            hook: Mutex::new(None),
            #[cfg(feature = "test-hooks")]
            page_fault: Mutex::new(None),
        })
    }

    /// A payload for a copy of a page: one kept from an earlier commit, or a new one.
    fn payload_for_copy(&self) -> Result<PayloadBuf> {
        let spare = self
            .payloads
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .pop();
        krummi_pager::reuse_payload(spare)
    }

    /// Keeps the payloads of a commit's pages for the next copies, up to [`SPARE_PAYLOADS`], in a store on disk.
    fn keep_payloads(&self, pages: Vec<(u64, PayloadBuf)>) {
        if self.folder.is_none() {
            return;
        }
        let mut spare = self.payloads.lock().unwrap_or_else(PoisonError::into_inner);
        let room = SPARE_PAYLOADS.saturating_sub(spare.len());
        spare.extend(pages.into_iter().take(room).map(|(_, payload)| payload));
    }

    /// Page payloads kept for the next copies (tests).
    #[cfg(test)]
    pub(crate) fn spare_payloads(&self) -> usize {
        self.payloads
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .len()
    }

    /// The store's folder, or `None` for a temporary store: the data of most errors (T18).
    pub fn folder(&self) -> Option<&Path> {
        self.folder.as_deref()
    }

    /// Information about the store (P12): `krummi.data` as it is (T14), and its free pages as of what a read
    /// opened now would see (F10). It reads no page, so it always works.
    pub fn info(&self) -> Info {
        let mut info = self.scratch.info();
        info.free_pages = self
            .space
            .free_pages(self.scratch.visible_txid(), info.page_count);
        info
    }

    /// Opens a read transaction: a snapshot of everything committed so far (T2, T7).
    pub fn read(&self) -> Result<ReadTransaction<'_>> {
        Ok(ReadTransaction::new(self.scratch.snapshot()?))
    }

    /// Opens the write transaction, waiting for the turn in order of arrival (T3), at most `limit` when given
    /// (T4). Fails without waiting with the misuse class when this thread already has one open (T5) or the limit
    /// cannot be counted from now, and with the I/O class when the store refuses writes (T12), in that order
    /// (T13).
    pub fn write(&self, limit: Option<Duration>) -> Result<WriteTransaction<'_>> {
        let me = thread::current().id();
        let mut queue = self.lock_queue();
        if queue.owner == Some(me) {
            return Err(self.misuse("a write transaction is already open on this thread"));
        }
        let deadline = match limit {
            None => None,
            Some(limit) => match Instant::now().checked_add(limit) {
                Some(deadline) => Some(deadline),
                None => return Err(self.misuse("the wait limit is too large")),
            },
        };
        if queue.io_failed || !self.scratch.pager().accepts_writes() {
            return Err(self.writes_refused());
        }
        if queue.owner.is_some() || !queue.waiting.is_empty() {
            if limit == Some(Duration::ZERO) {
                return Err(self.timeout(limit));
            }
            queue = self.wait_turn(queue, deadline, limit)?;
        }
        queue.owner = Some(me);
        drop(queue);
        match self.scratch.begin_write() {
            Ok(writer) => Ok(WriteTransaction::new(self, writer)),
            Err(error) => {
                self.release_turn();
                Err(error)
            }
        }
    }

    /// Makes durable every commit that passed its point of no return, deferred ones and ones that have not returned
    /// included (J11 of the Journal PRD, E10 of the grouped journal PRD). It does not wait for the open write
    /// transaction. Fails at once with the I/O class when the store refuses writes (T12).
    pub fn make_durable(&self) -> Result<()> {
        let result = self.scratch.make_durable();
        if result.is_err() {
            self.note_failure();
        }
        result
    }

    /// Closes the store: transfers what was committed to `krummi.data`, removes the journal and releases its
    /// lock, which is released even if writing fails; then the journal stays for the next opening (J14, P14).
    /// Dropping an `Engine` does the same, without reporting a failure.
    pub fn close(self) -> Result<()> {
        self.scratch.close()
    }

    /// Waits until commit `txid` is durable (J4, E4); a failed group fails it with the I/O class and the waiting
    /// requests with it (E8, T12).
    fn wait_durable(&self, txid: u64) -> Result<()> {
        let result = self.scratch.wait_durable(txid);
        if result.is_err() {
            self.note_failure();
        }
        result
    }

    /// Runs a transfer pass now on this thread, as the transfer thread does, and returns whether the store still
    /// accepts writes; a failure makes it refuse them, which the next operations report (tests: AC-E17, J13).
    #[cfg(feature = "test-hooks")]
    pub fn transfer_now(&self) -> bool {
        if self.scratch.transfer().is_err() {
            self.note_failure();
        }
        self.scratch.pager().accepts_writes()
    }

    /// Flips every bit of byte `offset` of the payload of page `page_number` in the store, without changing its
    /// checksum, as damage that appears while the store is open; borrowing the engine mutably proves that no
    /// transaction is open (tests of the remembered node layout check PRD). The page must be intact and transferred:
    /// with a version in the scratch area, reads would see that version, so it panics.
    #[cfg(feature = "test-hooks")]
    pub fn flip_byte_in_place(&mut self, page_number: u64, offset: usize) -> Result<()> {
        self.scratch.flip_byte_in_place(page_number, offset)
    }

    /// Contents whose layout the tree code remembered as checked since the store opened, one per successful check of
    /// a verified page (tests of the remembered node layout check PRD).
    #[cfg(feature = "test-hooks")]
    pub fn checked_remembered(&self) -> u64 {
        self.scratch.pager().checked_remembered()
    }

    /// Slots of the store's table of checked contents (tests of the remembered node layout check PRD).
    #[cfg(feature = "test-hooks")]
    pub fn checked_slots(&self) -> usize {
        self.scratch.pager().checked_slots()
    }

    /// Layout checks of versions of the scratch area since the store opened, passed or failed (tests of the version
    /// checks PRD).
    #[cfg(feature = "test-hooks")]
    pub fn version_checks(&self) -> u64 {
        self.scratch.version_checks()
    }

    /// Integrity checks of the store's pages and runs since it opened (tests of the remembered page integrity PRD).
    #[cfg(feature = "test-hooks")]
    pub fn integrity_checks(&self) -> u64 {
        self.scratch.pager().integrity_checks()
    }

    /// Whether the integrity of page `page_number`, or of the run that starts there, is remembered (tests of the
    /// remembered page integrity PRD).
    #[cfg(feature = "test-hooks")]
    pub fn is_remembered(&self, page_number: u64) -> bool {
        self.scratch.pager().is_remembered(page_number)
    }

    /// Whether the run of `count` pages from page `first` is remembered as one run of that length (tests of the
    /// remembered page integrity PRD).
    #[cfg(feature = "test-hooks")]
    pub fn is_run_remembered(&self, first: u64, count: u64) -> bool {
        self.scratch.pager().is_run_remembered(first, count)
    }

    /// Sets the minimum time between transfer passes and the growth of the scratch area since the last pass from
    /// which a pass starts without waiting for it (tests).
    #[cfg(feature = "test-hooks")]
    pub fn set_transfer_pacing(&self, interval: Duration, bytes: u64) {
        self.scratch.set_transfer_pacing(interval, bytes);
    }

    /// Stops the transfer thread from starting passes, waiting for the one it may be running, or lets it go on
    /// (tests).
    #[cfg(feature = "test-hooks")]
    pub fn set_transfer_paused(&self, paused: bool) {
        self.scratch.set_transfer_paused(paused);
    }

    /// A flag that stays set while the transfer thread runs, also after the store closes (tests).
    #[cfg(feature = "test-hooks")]
    pub fn transfer_thread_alive(&self) -> Arc<AtomicBool> {
        self.scratch.transfer_thread_alive()
    }

    /// Transfers everything no read needs and records it in both header copies (tests: AC-J18).
    #[cfg(feature = "test-hooks")]
    pub fn checkpoint(&self) -> Result<()> {
        self.scratch.checkpoint()
    }

    /// Bytes of committed page versions that are not in `krummi.data` yet (tests).
    #[cfg(feature = "test-hooks")]
    pub fn scratch_bytes(&self) -> u64 {
        self.scratch.scratch_bytes()
    }

    /// Bytes the temporary area holds, free slots included: the files of `krummi.temp`, or the memory of a temporary
    /// store's versions (tests).
    #[cfg(feature = "test-hooks")]
    pub fn area_bytes(&self) -> u64 {
        self.scratch.area_bytes()
    }

    /// Where the bytes of a reference live, if in the store's pages or in the versions of the temporary area, not in
    /// a write's own changes (tests: AC20, AC-V3).
    #[cfg(feature = "test-hooks")]
    pub fn memory_of(&self, bytes: &[u8]) -> Option<Memory> {
        self.scratch.memory_of(bytes)
    }

    /// Transfer passes so far (tests).
    #[cfg(feature = "test-hooks")]
    pub fn transfer_passes(&self) -> u64 {
        self.scratch.transfer_passes()
    }

    /// Flushes of `krummi.data` to the disk so far (tests).
    #[cfg(feature = "test-hooks")]
    pub fn data_syncs(&self) -> u64 {
        self.scratch.pager().data_syncs()
    }

    /// Sets the size at which the journal goes on in a new file (tests).
    #[cfg(feature = "test-hooks")]
    pub fn set_journal_file_limit(&self, bytes: u64) {
        self.scratch.set_journal_file_limit(bytes);
    }

    /// Sets a function a durable commit calls between writing its journal record and flushing it (tests: AC-J13).
    #[cfg(feature = "test-hooks")]
    pub fn set_journal_sync_hook(&self, hook: Option<std::sync::Arc<dyn Fn() + Send + Sync>>) {
        self.scratch.set_journal_sync_hook(hook);
    }

    /// Stops the journal's writer from taking queued commits, or lets it go on (tests).
    #[cfg(feature = "test-hooks")]
    pub fn set_journal_paused(&self, paused: bool) {
        self.scratch.set_journal_paused(paused);
    }

    /// Number of commits waiting in the journal's queue (tests).
    #[cfg(feature = "test-hooks")]
    pub fn journal_queued(&self) -> usize {
        self.scratch.journal_queued()
    }

    /// Writes of groups so far, one per journal file a group touches (tests).
    #[cfg(feature = "test-hooks")]
    pub fn journal_writes(&self) -> u64 {
        self.scratch.journal_writes()
    }

    /// Last durable commit (tests).
    #[cfg(feature = "test-hooks")]
    pub fn journal_durable(&self) -> u64 {
        self.scratch.journal_durable()
    }

    /// Sets the bytes the journal's queue holds before a commit waits for room (tests).
    #[cfg(feature = "test-hooks")]
    pub fn set_journal_queue_limit(&self, bytes: u64) {
        self.scratch.set_journal_queue_limit(bytes);
    }

    /// Sets a function the transfer calls while it holds its lock, or none (tests: AC-J17).
    #[cfg(feature = "test-hooks")]
    pub fn set_transfer_hook(&self, hook: Option<std::sync::Arc<dyn Fn() + Send + Sync>>) {
        self.scratch.set_transfer_hook(hook);
    }

    /// Sets the pages of a region, smaller than [`REGION_PAGES`] so that tests reach several regions with small
    /// files. Set it right after opening, before any write, and to the same value on every opening of a store.
    #[cfg(feature = "test-hooks")]
    pub fn set_region_pages(&self, pages: u64) {
        self.space.set_region_pages(pages);
    }

    /// The frontier as the next writer sees it (tests: F3).
    #[cfg(feature = "test-hooks")]
    pub fn frontier(&self) -> u64 {
        self.space.frontier()
    }

    /// Regions whose map was read since opening (tests: F9).
    #[cfg(feature = "test-hooks")]
    pub fn regions_read(&self) -> usize {
        self.space.regions_read()
    }

    /// Sets the function called at each [`Point`], or none.
    #[cfg(feature = "test-hooks")]
    pub fn set_hook(&self, hook: Option<Hook>) {
        *self.hook.lock().unwrap_or_else(PoisonError::into_inner) = hook;
    }

    /// Makes operation number `nth` (from 0, from now on) on the pages of write transactions fail with `error`,
    /// without effect, as a failure of T11 would: reading a page (`page`), changing it (`page_mut`), reserving pages
    /// (`allocate`, `allocate_run`) or freeing them (`free`). `None` cancels it (tests: AC-B18).
    #[cfg(feature = "test-hooks")]
    pub fn set_page_fault(&self, fault: Option<(u64, Error)>) {
        *self
            .page_fault
            .lock()
            .unwrap_or_else(PoisonError::into_inner) = fault;
    }

    /// Whether the fault of [`Engine::set_page_fault`] is still waiting for its operation (tests).
    #[cfg(feature = "test-hooks")]
    pub fn page_fault_pending(&self) -> bool {
        self.page_fault
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .is_some()
    }

    /// The failure of [`Engine::set_page_fault`] when its operation comes, once.
    fn injected_fault(&self) -> Result<()> {
        #[cfg(feature = "test-hooks")]
        {
            let mut fault = self
                .page_fault
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            match fault.as_mut() {
                Some((0, _)) => return Err(fault.take().expect("matched above").1),
                Some((nth, _)) => *nth -= 1,
                None => {}
            }
        }
        Ok(())
    }

    /// Times a request waiting for the write turn woke up (tests).
    #[cfg(feature = "test-hooks")]
    pub fn turn_wakeups(&self) -> u64 {
        self.turns.wakeups.load(Ordering::Relaxed)
    }

    /// Number of requests waiting for the write turn, so tests can queue them in a known order.
    #[cfg(feature = "test-hooks")]
    pub fn queued(&self) -> usize {
        self.lock_queue().waiting.len()
    }

    fn hook(&self, point: Point) {
        #[cfg(feature = "test-hooks")]
        {
            let hook = self
                .hook
                .lock()
                .unwrap_or_else(PoisonError::into_inner)
                .clone();
            if let Some(hook) = hook {
                hook(point);
            }
        }
        #[cfg(not(feature = "test-hooks"))]
        let _ = point;
    }

    /// Queues a request and waits until it is first in the queue and the write transaction is free.
    fn wait_turn<'q>(
        &'q self,
        mut queue: MutexGuard<'q, Queue>,
        deadline: Option<Instant>,
        limit: Option<Duration>,
    ) -> Result<MutexGuard<'q, Queue>> {
        let ticket = queue.next_ticket;
        queue.next_ticket += 1;
        let wake = Arc::new(Condvar::new());
        queue.waiting.push_back(Waiter {
            ticket,
            wake: Arc::clone(&wake),
        });
        loop {
            // Every waiting request was woken when the store started refusing writes.
            if queue.io_failed {
                leave(&mut queue, ticket);
                return Err(self.writes_refused());
            }
            if queue.owner.is_none() && queue.waiting.front().map(|w| w.ticket) == Some(ticket) {
                queue.waiting.pop_front();
                return Ok(queue);
            }
            queue = match deadline {
                None => wake.wait(queue).unwrap_or_else(PoisonError::into_inner),
                Some(deadline) => {
                    let now = Instant::now();
                    if now >= deadline {
                        // Leaving wakes nobody: had this request been first with the turn free, it would have
                        // taken the turn above; otherwise the first one is woken by whoever releases the turn.
                        leave(&mut queue, ticket);
                        return Err(self.timeout(limit));
                    }
                    wake.wait_timeout(queue, deadline - now)
                        .unwrap_or_else(PoisonError::into_inner)
                        .0
                }
            };
            self.turns.wakeups.fetch_add(1, Ordering::Relaxed);
        }
    }

    /// Ends the turn of the write transaction; the first request in the queue gets it (T3, T10), and only that
    /// request is woken.
    fn release_turn(&self) {
        let waiting = {
            let mut queue = self.lock_queue();
            queue.owner = None;
            !queue.waiting.is_empty()
        };
        if waiting {
            self.hook(Point::Handoff);
            self.lock_queue().wake_next();
        }
    }

    /// Records that the store refuses writes, if it does: the waiting requests fail at once (T12).
    fn note_failure(&self) {
        if !self.scratch.pager().accepts_writes() {
            self.turns.refuse_writes();
            self.scratch.wake();
        }
    }

    fn lock_queue(&self) -> MutexGuard<'_, Queue> {
        self.turns
            .queue
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
    }

    pub(crate) fn misuse(&self, reason: &'static str) -> Error {
        Error::Misuse {
            folder: self.folder.clone(),
            reason,
        }
    }

    fn timeout(&self, limit: Option<Duration>) -> Error {
        Error::Timeout {
            folder: self.folder.clone(),
            limit: limit.unwrap_or_default(),
        }
    }

    fn writes_refused(&self) -> Error {
        Error::Io {
            folder: self.folder.clone().unwrap_or_default(),
            source: io::Error::other("writes are refused after a failed write; reopen the store"),
        }
    }
}

/// Whether `krummi.data` has no meta page yet: nothing was ever written to it. A store whose meta page lives only
/// in the scratch area is not blank for its readers, which find that version first.
fn meta_is_blank(pager: &Pager) -> bool {
    pager.page_count() <= META_PAGE || pager.page_is_blank(META_PAGE)
}

/// The `u64` at byte `at` of the meta page's payload.
fn meta_field(meta: &[u8], at: usize) -> u64 {
    u64::from_le_bytes(meta[at..at + 8].try_into().expect("8 bytes"))
}

/// Byte offset of `slot` in the meta page's payload.
///
/// # Panics
///
/// If `slot` is not below [`META_SLOTS`].
fn slot_offset(slot: usize) -> usize {
    assert!(slot < META_SLOTS, "the meta page has {META_SLOTS} slots");
    SLOTS_OFFSET + slot * 8
}

fn leave(queue: &mut Queue, ticket: u64) {
    queue.waiting.retain(|w| w.ticket != ticket);
}
