use std::cell::RefCell;
use std::time::Instant;
#[derive(Clone,Copy,Default)] struct Stat {calls:u64,samples:u64,ns:u64}
thread_local! {static DATA: RefCell<(bool,[Stat;64])> = const { RefCell::new((false,[Stat{calls:0,samples:0,ns:0};64])) };}
pub struct Guard {id:usize, start:Option<Instant>}
impl Guard {#[inline] pub fn new(id:usize,mask:u64)->Self {
 let enabled=DATA.with(|d|{let mut d=d.borrow_mut();if !d.0{return false};d.1[id].calls+=1; (d.1[id].calls & mask)==0});
 Self{id,start:enabled.then(Instant::now)}
}}
impl Drop for Guard {#[inline] fn drop(&mut self){if let Some(t)=self.start{let ns=t.elapsed().as_nanos() as u64;DATA.with(|d|{let mut d=d.borrow_mut();d.1[self.id].ns+=ns;d.1[self.id].samples+=1;});}}}
pub fn enable(on:bool){DATA.with(|d|d.borrow_mut().0=on);}
pub fn report(){DATA.with(|d|{let mut d=d.borrow_mut();for (i,s) in d.1.iter().enumerate(){if s.calls>0{eprintln!("diag {} {} {} {}",NAMES.get(i).unwrap_or(&"unknown"),s.calls,s.samples,s.ns);}}d.1=[Stat::default();64];});}
const NAMES: &[&str] = &["row_check", "row_encode", "row_patch", "row_decode", "row_content_check", "get_located", "overwrite", "tree_update", "multi_entry", "multi_encode", "multi_store", "copy_for_write", "reserve_run", "commit", "finish_space", "seal_runs", "scratch_commit", "stage", "publish", "encode_record", "page_diff", "store_run", "temp_allocate_and_fill", "descend", "compress", "durable_wait"];
thread_local! {static COUNTS:RefCell<[u64;8]>=const {RefCell::new([0;8])};}
pub fn count(i:usize,n:u64){if DATA.with(|d|d.borrow().0){COUNTS.with(|c|c.borrow_mut()[i]+=n);}}
pub fn counts(){COUNTS.with(|c|{eprintln!("counts {:?}",*c.borrow());*c.borrow_mut()=[0;8];});}
